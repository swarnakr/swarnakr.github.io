clc; clear all;
% 
% path1='E:\CS669\PRassign2\Group01\class1\';
% extn='.txt';
% path=sprintf('%s%d%s', path1, 1, extn);
% A=load(path);
% for i=1:160
%     path=sprintf('%s%d%s', path1, i, extn);
%     A1=load(path);
%     A=[A;A1];
% end
% 
% path2='E:\CS669\PRassign2\Group01\class2\';
% path=sprintf('%s%d%s', path2, 1, extn);
% B=load(path);
% for i=1:160
%     path=sprintf('%s%d%s', path2, i, extn);
%     B1=load(path);
%     B=[B;B1];
% end
% 
% path3='E:\CS669\PRassign2\Group01\class3\';
% path=sprintf('%s%d%s', path3, 1, extn);
% C=load(path);
% for i=1:160
%     path=sprintf('%s%d%s', path3, i, extn);
%     C1=load(path);
%     C=[C;C1];
% end
% 
% Z=[A;B;C];
% 
% save 'VQ_Data.txt' Z -ascii; % Save the feature vectors into a file

A=load('VQ_Data.txt');
k=8;
rows=size(A,1);
KM=kMeansCluster(A,k);

save 'clusters_new.txt' KM -ascii; % Save the cluster index into a file

% KM=load('clusters_new.txt');
% n1=0;n2=0;n3=0;n4=0;n5=0;n6=0;n7=0;
% for i=1:rows
%     if(KM(i)==1)
%         n1=n1+1;
%         A1(n1,:)=A(i,:);
%     end
%     if(KM(i)==2)
%         n2=n2+1;
%         A2(n2,:)=A(i,:);
%     end
%     if(KM(i)==3)
%         n3=n3+1;
%         A3(n3,:)=A(i,:);
%     end
%     if(KM(i)==4)
%         n4=n4+1;
%         A4(n4,:)=A(i,:);
%     end
%     if(KM(i)==5)
%         n5=n5+1;
%         A5(n5,:)=A(i,:);
%     end
%     if(KM(i)==6)
%         n6=n6+1;
%         A6(n6,:)=A(i,:);
%     end
%     if(KM(i)==7)
%         n7=n7+1;
%         A7(n7,:)=A(i,:);
%     end    
% end

% M1=mean(A1);M2=mean(A2);M3=mean(A3);M4=mean(A4);M5=mean(A5);M6=mean(A6);M7=mean(A7);
 
