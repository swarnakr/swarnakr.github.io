clc; clear all; close all;

N=6; % No of states
M=8; % No of symbols
L=120; % test data
extn='.txt';

pi(1:N)=0; pi(1)=1;

a=[1/3 1/3 1/3 0   0   0
   0   1/3 1/3 1/3 0   0 
   0   0   1/3 1/3 1/3 0  
   0   0   0   1/3 1/3 1/3 
   0   0   0   0   1/2 1/2 
   0   0   0   0   0   1  ];

b=[ 0.1238    0.0125         0    0.0013    0.1158    0.0102    0.0009    0.7355
    0.3477    0.1242    0.0004    0.0276    0.0240    0.0543    0.0067    0.4150
    0.2471    0.2827    0.0031    0.2275    0.0089    0.0387    0.1305    0.0614
    0.0160    0.0908    0.0775    0.5810    0.0258    0.0708    0.1278    0.0102
    0.0129    0.0036    0.2845    0.2578    0.2012    0.1215    0.0058    0.1126
    0.0619    0.0004    0.0574    0.0049    0.4252    0.0499         0    0.4003];
Prob=zeros(1,L);Prob1=zeros(1,L);
path1='E:\CS669\fromPRassign2\DataVectors_new\1\';

eta=zeros(N,N);etasum=zeros(N,N);etasum1=zeros(N,N);
etab=zeros(N,N);etabsum=zeros(N,N);etabsum1=zeros(N,N);
gammasum=zeros(1,N);gammasum1=zeros(1,N);
gammab=zeros(N,M);
gammabsum=zeros(N,M);gammabsum1=zeros(N,M);

anew=a;bnew=b;pinew=pi;
% Re-estimation
b1=1;b2=1;b3=1;
while( b1&b2&b3)
    a=anew;
    b=bnew;
    pi=pinew;
for n=1:L
    clear alpha; clear gamma; clear etasum;  
    clear beta; clear gammab; clear gammabsum;   
    path=sprintf('%s%d%s', path1, n, extn);
    O=load(path);   
    T=size(O,2);
    alpha=zeros(T,N);beta=zeros(T,N);gamma=zeros(T,N);
    gammab=zeros(N,M);gammabsum=zeros(N,M);
    etasum=zeros(N,N);etabsum=zeros(N,N);
    
%INITIALIZATION STEP
    for i=1:N
        alpha(1,i)=pi(i)*b(i,O(1));
    end
    %INDUCTION STEP
    for t=1:T-1
        for j=1:N
            p=0;
            for i=1:N
                p=p+alpha(t,i)*a(i,j);
            end
            alpha(t+1,j)=p*b(j,O(t+1));
        end
    end

    %INITIALIZATION STEP
    for j=1:N
        beta(T,j)=1;
    end
     
    %INDUCTION STEP
    for t=T-1:-1:1
        for i=1:N
            for j=1:N
                beta(t,i)=beta(t,i)+a(i,j)*b(j,O(t+1))*beta(t+1,j);
            end
        end
    end
    
    %TERMINATION STEP    
        for i=1:N
            Prob(n)=Prob(n)+pi(i)*b(i,O(1))*beta(1,i);
        end
        
    %COMPUTING ETA     
    for t=1:T-1
        eta=zeros(N,N);
        for i=1:N
            for j=1:N
                eta(i,j)=(alpha(t,i)*a(i,j)*b(j,O(t+1))*beta(t+1,j))/Prob(n);          
            end
        end
                        
        %COMPUTING GAMMA        
        for i=1:N
            gamma(t,i)=sum(eta(i,:));
        end
          etasum=etasum+eta;
    end
    gammasum=sum(gamma);
    etasum1=etasum1+etasum;   
    gammasum1=gammasum1+gammasum;

    for k=1:M
        for t=1:T-1
            if(O(t)==k)
                gammab(:,:)=0;
                gammab(:,k)=gamma(t,:)';
                gammabsum=gammabsum+gammab;
            end
        end
    end
    gammabsum1=gammabsum1+gammabsum;
        
    pi(1:N)=pi(1:N)+gamma(1,:);
        
end

    pinew(1:N)=pi(:)/L;

for i=1:N
    for j=1:N
        if(gammasum1(i)==0)
            gammasum1(i)=0.0001;
        else
            anew(i,j)=etasum1(i,j)/gammasum1(i);            
        end
    end
end

for k=1:M
    for j=1:N
        bnew(j,k)=gammabsum1(j,k)/gammasum1(j);
    end
end

if(abs(a-anew)<0.01)   b1=0; end
if(abs(b-bnew)<0.01)   b2=0; end
if(abs(pi-pinew)<0.01) b3=0; end
end
   
save 'a1new.txt' anew -ascii;
save 'b1new.txt' bnew -ascii;
save 'pi1new.txt' pinew -ascii;
