function y=kMeansCluster(m,k)
  
[maxRow, maxCol]=size(m);
y=zeros(maxRow,1);
% initial value of centroid
p = randperm(size(m,1));      % random initialization
for i=1:k
    c(i,:)=m(p(i),:);  % centroid coordinate size (1:k, 1:maxCol)
end

temp=zeros(maxRow,1);   % initialize as zero vector
n=maxRow;

while 1
    d=DistMatrix(m,c);  % calculate object-centroid distances
    [z,g]=min(d,[],2);  % find current iteration group matrix size (1:maxRow)
    if g==temp,
        break;          % stop the iteration
    else
        temp=g;         % copy group matrix to temporary variable
    end
    for i=1:k
        f=find(g==i);   %row number of data that belong to group i
        if f            % only compute centroid if f is not empty
            c(i,:)=mean(m(find(g==i),:),1);
        end
    end
end
y=g;
end

   