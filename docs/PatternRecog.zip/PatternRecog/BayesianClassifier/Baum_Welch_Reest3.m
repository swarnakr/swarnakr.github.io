clc; clear all; close all;

N=5; % No of states
M=8; % No of symbols
L=120; % test data
extn='.txt';
pi(1:N)=0; pi(1)=1;

a=[1/3 1/3 1/3 0   0   
   0   1/3 1/3 1/3 0    
   0   0   1/3 1/3 1/3   
   0   0   0   1/2 1/2 
   0   0   0   0   1 ];

b=[ 0.1420    0.0054    0.2163    0.1771    0.0875    0.0631         0    0.3087
    0.2423    0.0004    0.1775    0.0871    0.1383    0.0660    0.0045    0.2839
    0.2712         0    0.2097    0.0953    0.0784    0.0355    0.0037    0.3062
    0.2216    0.0029    0.2249    0.0937    0.0784    0.0499    0.0025    0.3260
    0.1473    0.0235    0.2790    0.0966    0.0825    0.0541    0.0029    0.3141];

Prob=zeros(1,L);Prob1=zeros(1,L);
path1='E:\CS669\fromPRassign2\DataVectors_new\3\';

eta=zeros(N,N);etasum=zeros(N,N);etasum1=zeros(N,N);
etab=zeros(N,N);etabsum=zeros(N,N);etabsum1=zeros(N,N);
gammasum=zeros(1,N);gammasum1=zeros(1,N);
gammab=zeros(N,M);gammabsum=zeros(N,M);gammabsum1=zeros(N,M);

anew=a;bnew=b;pinew=pi;

% Re-estimation
b1=1;b2=1;b3=1;
while( b1&b2&b3)
    a=anew;
    b=bnew;
    pi=pinew;
for n=1:L
    clear alpha; clear gamma; clear etasum;  
    clear beta; clear gammab; clear gammabsum;   
    path=sprintf('%s%d%s', path1, n, extn);
    O=load(path);   
    T=size(O,2);
    alpha=zeros(T,N); beta=zeros(T,N);
    gamma=zeros(T,N); gammab=zeros(N,M); gammabsum=zeros(N,M);
    etasum=zeros(N,N); etabsum=zeros(N,N);
    
%INITIALIZATION STEP
    for i=1:N
        alpha(1,i)=pi(i)*b(i,O(1));
    end
    %INDUCTION STEP
    for t=1:T-1
        for j=1:N
            p=0;
            for i=1:N
                p=p+alpha(t,i)*a(i,j);
            end
            alpha(t+1,j)=p*b(j,O(t+1));
        end
    end

    %INITIALIZATION STEP
    for j=1:N
        beta(T,j)=1;
    end
     
    %INDUCTION STEP
    for t=T-1:-1:1
        for i=1:N
            for j=1:N
                beta(t,i)=beta(t,i)+a(i,j)*b(j,O(t+1))*beta(t+1,j);
            end
        end
    end
    
    %TERMINATION STEP    
    for i=1:N
        Prob(n)=Prob(n)+pi(i)*b(i,O(1))*beta(1,i);
    end

    %COMPUTING ETA     
    for t=1:T-1
        eta=zeros(N,N);
        for i=1:N
            for j=1:N
                eta(i,j)=(alpha(t,i)*a(i,j)*b(j,O(t+1))*beta(t+1,j))/Prob(n);
            end
        end
                        
        %COMPUTING GAMMA        
        for i=1:N
            gamma(t,i)=sum(eta(i,:));
        end
        etasum=etasum+eta;
    end
    gammasum=sum(gamma);
    etasum1=etasum1+etasum;   
    gammasum1=gammasum1+gammasum;
    for k=1:M
        for t=1:T-1
            if(O(t)==k)
                gammab(:,:)=0;
                gammab(:,k)=gamma(t,:)';
                gammabsum=gammabsum+gammab;
            end
        end
    end
    gammabsum1=gammabsum1+gammabsum;
        
    pi(1:N)=pi(1:N)+gamma(1,:);
        
end

    pinew(1:N)=pi(:)/L;

for i=1:N
    for j=1:N
        if(gammasum1(i)==0)
            gammasum1(i)=0.0001;
        else
            anew(i,j)=etasum1(i,j)/gammasum1(i);            
        end
    end
end

for k=1:M
    for j=1:N
        bnew(j,k)=gammabsum1(j,k)/gammasum1(j);
    end
end

if(abs(a-anew)<0.01)   b1=0; end
if(abs(b-bnew)<0.01)   b2=0; end
if(abs(pi-pinew)<0.01) b3=0; end
end
    
save 'a3new.txt' anew -ascii;
save 'b3new.txt' bnew -ascii;
save 'pi3new.txt' pinew -ascii;
