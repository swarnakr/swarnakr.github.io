clc; clear all; 

N1=6;N2=4;N3=5; % No of states
M=8; % No of symbols
extn='.txt';

a1=load('a1new.txt');a2=load('a2new.txt');a3=load('a3new.txt');
b1=load('b1new.txt');b2=load('b2new.txt');b3=load('b3new.txt');
pi1=load('pi1new.txt');pi2=load('pi2new.txt');pi3=load('pi3new.txt');

path1='J:\PRassign2\DataVectors_new\2\';
k=0;
for n=121:160
    clear alpha1; clear alpha2; clear alpha3; 
    clear beta1;  clear beta2;  clear beta3; 
    path=sprintf('%s%d%s', path1, n, extn);
    O=load(path);   
    T=size(O,2);
    alpha1=zeros(T,N1);alpha2=zeros(T,N2);alpha3=zeros(T,N3);
    beta1=zeros(T,N1); beta2=zeros(T,N2); beta3=zeros(T,N3);
    
    %INITIALIZATION STEP
    for i=1:N1         alpha1(1,i)=pi1(i)*b1(i,O(1)); end
    for i=1:N2         alpha2(1,i)=pi2(i)*b2(i,O(1)); end
    for i=1:N3         alpha3(1,i)=pi3(i)*b3(i,O(1)); end
    %INDUCTION STEP
    for t=1:T-1
        for j=1:N1
            p1=0;
            for i=1:N1
                p1=p1+alpha1(t,i)*a1(i,j);
            end
            alpha1(t+1,j)=p1*b1(j,O(t+1));
        end
        for j=1:N2
            p2=0;
            for i=1:N2
                p2=p2+alpha2(t,i)*a2(i,j);
            end
            alpha2(t+1,j)=p2*b2(j,O(t+1));
        end
        for j=1:N3
            p3=0;
            for i=1:N3
                p3=p3+alpha3(t,i)*a3(i,j);
            end
            alpha3(t+1,j)=p3*b3(j,O(t+1));
        end
    end

    %INITIALIZATION STEP
    for j=1:N1   beta1(T,j)=1;  end
    for j=1:N2   beta2(T,j)=1;  end
    for j=1:N3   beta3(T,j)=1;  end
    
     
    %INDUCTION STEP
    for t=T-1:-1:1
        for i=1:N1
            for j=1:N1
                beta1(t,i)=beta1(t,i)+a1(i,j)*b1(j,O(t+1))*beta1(t+1,j);               
            end            
        end
        for i=1:N2
            for j=1:N2
                beta2(t,i)=beta2(t,i)+a2(i,j)*b2(j,O(t+1))*beta2(t+1,j);              
            end             
        end
        for i=1:N3
            for j=1:N3
                beta3(t,i)=beta3(t,i)+a3(i,j)*b3(j,O(t+1))*beta3(t+1,j);            
            end            
        end
    end
    
    %TERMINATION STEP 
    g(1:3)=0;
    k=k+1;
    for i=1:N1        g(1)=g(1)+pi1(i)*b1(i,O(1))*beta1(1,i);           end
    for i=1:N2        g(2)=g(2)+pi2(i)*b2(i,O(1))*beta2(1,i);           end
    for i=1:N3        g(3)=g(3)+pi3(i)*b3(i,O(1))*beta3(1,i);           end

    [z,index]=max(g);
    class(k)=index;   
end
class