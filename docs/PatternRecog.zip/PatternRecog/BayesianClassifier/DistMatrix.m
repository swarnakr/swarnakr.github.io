function d=DistMatrix(A,B)

% computes euclidean distance between matrices
[hA,wA]=size(A);
[hB,wB]=size(B);
for k=1:wA
    C{k}= repmat(A(:,k),1,hB);
    D{k}= repmat(B(:,k),1,hA);
end
S=zeros(hA,hB);
for k=1:wA
    S=S+(C{k}-D{k}').^2;
end
d=sqrt(S);
