% BAYES CLASSIFIER BAYESIAN ESTIMATION REAL DATASET4

clc; clear all; close all;

A11=load('../dataset2class1.txt');
A22=load('../dataset2class2.txt');
A33=load('../dataset2class3.txt');

R1=randperm(50);
for i=1:50
    A1(i,:)=A11(R1(i),:);
end
R2=randperm(50);
for i=1:50
    A2(i,:)=A22(R2(i),:);
end
R3=randperm(50);
for i=1:50
    A3(i,:)=A33(R3(i),:);
end

% taking 75% of data for training
% t=round(50*0.75);
t=floor(50*0.25)
train(1:t,:)=A1(1:t,:);
train((t+1):(2*t),:)=A2(1:t,:);
train((2*t+1):(3*t),:)=A3(1:t,:);

%calculating mean
M1=mean(A1(1:t,:))';
M2=mean(A2(1:t,:))';
M3=mean(A3(1:t,:))';

%calculating covariance
C1=cov(A1(1:t,:));
C2=cov(A2(1:t,:));
C3=cov(A3(1:t,:));

m01=rand(4,1)+M1;
m02=rand(4,1)+M2;
m03=rand(4,1)+M3;

c01=rand(4,4)+C1;
c02=rand(4,4)+C2;
c03=rand(4,4)+C3;

M1n=c01* inv(c01+(1/t)*C1) * M1 + (1/t)*C1* inv(c01+(1/t)) *C1 *m01;
M2n=c02* inv(c02+(1/t)*C2) * M2 + (1/(50*0.75))*C2* inv(c02+(1/t)) *C2 *m02;
M3n=c03* inv(c03+(1/t)*C3) * M3 + (1/t)*C3* inv(c03+(1/t)) *C3 *m03;

C1n = c01* inv(c01+(1/t)*C1) * (1/t) * C1;
C2n = c02* inv(c02+(1/t)*C2) * (1/t) * C2;
C3n = c03* inv(c03+(1/t)*C3) * (1/t) * C3; 

% tt=floor(50*0.25)
tt=round(50*0.75)
test(1:tt,:)=A1((t+1):50,:);
test((tt+1):(2*tt),:)=A2((t+1):50,:);
test((2*tt+1):(3*tt),:)=A3((t+1):50,:);

x1=zeros(4,1);
% [row,col]=size(test);
[row,col]=size(train);
for i=1:row
%     x1(1)=test(i,1);
%     x1(2)=test(i,2);
%     x1(3)=test(i,3);
%     x1(4)=test(i,4);
    x1(1)=train(i,1);
    x1(2)=train(i,2);
    x1(3)=train(i,3);
    x1(4)=train(i,4);
    g(1)=( (-0.5)*(x1-M1n)'*inv(C1+C1n)*(x1-M1n) ) - ( 0.5*log(det(C1+C1n)) ) + log(1/3);         
    g(2)=( (-0.5)*(x1-M2n)'*inv(C2+C2n)*(x1-M2n) ) - ( 0.5*log(det(C2+C2n)) ) + log(1/3);
    g(3)=( (-0.5)*(x1-M3n)'*inv(C3+C3n)*(x1-M3n) ) - ( 0.5*log(det(C3+C3n)) ) + log(1/3);
    [z,index]=max(g);
    class(i)=index;   
end

class

% computing confusion matrix 
N=0.25
T1=floor(50*N);
T2=(100*N-1);
T3=floor(150*N-1);

trgt=ones(1,(floor(150*0.25-1)));
trgt(1,1:T1)=1;
trgt(1,T1+1:T2)=2;
trgt(1,T2+1:T3)=3;

conf_matrix = zeros(3,3);
for z=1:T3
    conf_matrix(trgt(z),class(z)) = conf_matrix(trgt(z),class(z))+ 1;
end

for i=1:3
    class_accuracy(i)=(sum(conf_matrix(i,i))/T1)*100;
end

conf_matrix
class_accuracy
overall_accuracy=(sum(diag(conf_matrix))/T3)*100
