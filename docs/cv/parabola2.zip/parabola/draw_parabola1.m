function draw_parabola1(centrex, centrey, p, phi,no)
%centrex=50; centrey=90; p=30; phi=3*pi/2;
I= imread(sprintf('/home/visionlab2/swarna/Swarna_BackUp/pranav/Desktop/parabola/T%d.bmp',no));
I=rgb2gray(I);
Ires = imresize(I,1/10);
imshow(Ires)
hold on;
syms cx cy a theta x y; 
f=((y-cy)*cos(theta)-(x-cx)*sin(theta))^2 - 4*a*((y-cy)*sin(theta)+(x-cx)*cos(theta)) ; 
for i=1:size(p,2)
    subval=[centrex(i,1) centrey(i,1) p(1,i) phi(1,i)];
    fsub=subs(f, [cx cy a theta], subval);
    ezplot(fsub,[1,size(I,1),1,size(I,2)])
end
to_makewait=1;




% 
% 
% for i=1:size(p,2)
%     subval0=[centrex(1,i) centrey(1,i) p(1,i) phi(1,i)];
%     ysamp1=[];ysamp2=[];
%     for xval=1:100
%         subval=[subval0 xval];
%         fsub=subs(f, [cx cy a theta x], subval);
%         yval=solve(fsub,y);
%         ysamp1=[ysamp1 yval(1,1)];
%         ysamp2=[ysamp2 yval(2,1)];
%     end
%     xsamp=[1:100];
%     figure; plot(xsamp,ysamp);
% end