
%[(y-centroy)*cos(phi)-(x-centrox)*sin(phi)]^2=4*p*[(y-centroy)*sin(phi)+(x-centrox)*cos(phi)]
% s
for no=10:18
I= imread(sprintf('/home/visionlab2/swarna/Swarna_BackUp/pranav/Desktop/parabola/T%d.bmp',no));
 I=rgb2gray(I);
 Ires = imresize(I,1/2);
BW = edge(Ires,'canny');
imshow(BW)

% I= imread(sprintf('/home/visionlab2/swarna/Swarna_BackUp/pranav/Desktop/parabola/parabola1.png'));
% BW=im2bw(I);
 


houghparabola(BW,no)

end




%binary=im2bw(Ires); 
% bindil=bwmorph(BW,'dilate');
% binerode=bwmorph(bindil,'erode',2);