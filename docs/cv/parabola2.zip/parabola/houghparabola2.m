function [phi,p,centrex,centrey,acc]=houghparabola2(Imbinary,no,look)

%Comments:
%       Function uses Standard Hough Transform to detect parabola in a 
%       binary image. According to the Hough Transform, each pixel in image
%       space corresponds to a parabola in Hough space and vise versa. This
%       function uses the representation of parabola: 
%       [(y-centroy)*cos(phi)-(x-centrox)*sin(phi)]^2=...
%               ...=4*p*[(y-centroy)*sin(phi)+(x-centrox)*cos(phi)]
%       to detect parabola in binary image.
%       Upper left corner of image is the origin of coordinate system.
%
%Usage: [phi,p] = houghparabola(Imbinary,centrox,centroy,pmin,pmax)
%
%Arguments:
%       Imbinary - a binary image. image pixels that have value equal to 1 
%                  are interested pixels for HOUGHPARABOLA function.
%       centrox  - column coordinates of the parabola vertex.
%       centroy  - row coordinates of the parabola vertex.
%       pmin     - minimum possible value of the distance p between the 
%                  vertex and focus of the parabola.
%       pmax     - maximum possible value of the distance p between the 
%                  vertex and focus of the parabola.

%Returns:
%       phi      - angle of the detected parabola in polar coordinates
%       p        - distance between vertex and focus of the detected
%                  parabola.
%

[y,x] = find(Imbinary);
%y=size(Imbinary,1)-y1;
centrox=x;
centroy=y;
pmin=-15;  pmax=15;%pmax=max(size(Imbinary))/2;
vector_p=linspace(-pmax,pmax,40);
vector_phi=linspace(0,2*pi-(2*pi/100),50);
%vector_phi=[0 3.14/2 3*3.14/2 3.14];
Accumulator = zeros(length(vector_phi),length(vector_p),length(centrox));

%Voting
for i = 1:length(x)
    i
      for j= 1:length(vector_phi)
      for k=1:length(centrox)
           Y=y(i)-centroy(k);
           X=x(i)-centrox(k);
           angle=vector_phi(j);
           numerator=(Y*cos(angle)-X*sin(angle))^2;
           denominator=4*(X*cos(angle)+Y*sin(angle));
           if denominator~=0
               p=numerator/denominator;

               if abs(p)>pmin&abs(p)<pmax&p~=0
                   indice=find(vector_p>=p);
                   indice=indice(1);
                   Accumulator(j,indice,k) = Accumulator(j,indice,k)+1;
               end
           end
       end
   end
end

% Finding local maxima in Accumulator
for i=1:size(look,1)
    [u v r]=find(centrox==look(i,1) & centroy==look(i,2))
    maximum=max(max(Accumulator(:,:,u-5:u:u+5)));
    for j=1:size(maximum,3)
    [idx_phi,idx_p, idx_k]= ind2sub(size(Accumulator),find(Accumulator(:,:,u-5:u:u+5)>maximum(j)*0.9));
% [idx_phi2,idx_p2, idx_k2]= ind2sub(size(Accumulator),find(Accumulator(:,20:30,:)>maximum2*0.7));
% idx_phi=[idx_phi1; idx_phi2];
% idx_p=[idx_p1; idx_p2];
% idx_k=[idx_k1; idx_k2];
p=vector_p(idx_p)*5;
phi=vector_phi(idx_phi);
centrex=centrox(u+idx_k-5);
centrey=centroy(u+idx_k-5); centre=[centrex centrey];
% [u v r]=find(centre(:,1)<8 | centre(:,2)<8 | centre(:,1)>size(Imbinary,2)-10 | centre(:,2)>size(Imbinary,1)-10 );
% centrex(u,:)=[];centrey(u,:)=[];p(:,u)=[];phi(:,u)=[];
draw_parabola1(centrex,centrey,p,phi,no);
    end
end









% acc=zeros(length(vector_p),1); angle=3.14/2;
% for i = 1:length(x)
%            Y=y(i)-10;
%            X=x(i)-31;
%           
%            numerador=(Y*cos(angle)-X*sin(angle))^2;
%            denominador=4*(X*cos(angle)+Y*sin(angle));
%            if denominador~=0
%                p=numerador/denominador;
% 
%                if abs(p)>pmin&abs(p)<pmax&p~=0
%                    indice=find(vector_p>=p);
%                    indice=indice(1);
%                   acc(indice,1)=acc(indice,1)+1;
%                end
%            end
% end
