close all
clear all
%%%%% loading the noisy ECG signal %%%%%
load ecg1 -ascii
subplot(211)
plot(ecg1)
grid
title('Noisy ECG of 20 s duration')
xlabel('time samples')
ylabel('amplitude')
subplot(212)
plot(ecg1(1:500));
xlabel('time samples')
ylabel('amplitude')
grid
title('Same ECG as above but a clearer view with 3 beats only')
%%%% Frequency spectrum of the noisy ECG %%%%
ecgspec = abs(fft(ecg1,256)); %%% computes the magnitude spectrum %%%
ecgspec = ecgspec(1:128);
x = (1:128)*200/256; %%% normalizing to the correct freq. range %%%
figure
plot(x, ecgspec)
grid
xlabel('Frequency (Hz)')
ylabel('Magnitude')
title('Frequency spectrum of noisy ECG')
%%%%% ECG P R E P R O C E S S O R %%%%%
[b1,a1] =butter(6,0.7,'low');
%%%%% Plotting the magnitude and phase response of the lowpass filter %%%%
figure
freqz(b1, a1, 128, 200);
title('Mag. and Phase Response of the Lowpass Filter')
%%%%% Compute the output of the lowpass filter by using the filter command
op1 = filter(b1,a1,ecg1);
%%%%% Design the highpass filter 
[b2,a2] =butter(6,0.005,'high');
%%%%% Plotting the magnitude and phase response of the highpass filter %%%%
figure
freqz(b2, a2, 128, 200);
title('Mag. and Phase Response of the Highpass Filter')
%%%%% Compute the output of the highpass filter by using the filter command
op2 = filter(b2,a2,op1);
%%%%% From your transfer function derivation for the notch filter, plug in the
%%%%% num. coef. in b3, and the den. coef. a3 = [1]
b3 = [1 0.6180 1]; %%% fill your code
a3 = [1];
%%%%% Plotting the magnitude and phase response of the notch filter %%%%
figure
freqz(b3, a3, 128, 200);
title('Mag. and Phase Response of the Notch Filter')
figure
%%%%% Compute the output of the notch filter by using the filter command
opn = filter(b3,a3,op2);
%%%%% Plot the output of the notch filter (i.e, the output of the preprocessor)
plot(opn)
grid
title('Output of preprocessor')
xlabel('time samples')
ylabel('amplitude')
%%% fill your code %%%
%%%%% Plotting the magnitude and phase response of the combined system %%%%
bc = conv(b1,conv(b2,b3)); %%% num. coef. of the combined system
ac = conv(a1,conv(a2,a3)); %%% den. coef. of the combined system
figure
freqz(bc, ac, 128, 200);
title('Mag. and Phase Response of the Combined System (Preprocessor)')
figure
%%%% Pole-zero Map of the combined system %%%%
pzmap(bc,ac)
zgrid
%%%% Frequency spectrum of the preprocessed ECG %%%%
opnspec = abs(fft(opn,256)); %%% computes the magnitude spectrum %%%
opnspec = opnspec(1:128);
x = (1:128)*200/256; %%% normalizing to the correct freq. range %%%
figure
plot(x, opnspec)
grid
xlabel('Frequency (Hz)')
ylabel('Magnitude')
title('Frequency spectrum of the preprocessed ECG')
%%%%% ECG P R O C E S S O R %%%%%
%%%%% From your transfer function derivation for differentiator, plug in the
%%%%% num. coef. in b4, and the den. coef. a4 = [1]
b4 = [-1 1]; %%% fill your code
a4 = [1];
%%%%% Compute and plot the output of the differentiator (stage d) %%%
opd = filter(b4,a4,opn);
plot(opd);
grid
title('Output of differentiator')
xlabel('time samples')
ylabel('amplitude')
%%%%% Square and plot the output (stage e) %%%
ops=opd.^2;
plot(ops);
grid
title('Output after squaring')
xlabel('time samples')
ylabel('amplitude')
%%%%% From your transfer function derivation for the moving ave. filter, plug in
%%%%% the num. coef. in b5, and the den. coef. a5 = [1]
b5 = [.2 .2 .2 .2 .2]; %%% fill your code
a5 = [1];
%%%%% Compute and plot the output of the moving average filter (stage f) %%%
opav = filter(b5,a5,ops);
plot(opav);
grid
title('Output of moving average filter')
xlabel('time samples')
ylabel('amplitude')
%%%%% Counting of number of beats and heart rate by using a threshold (BONUS
close all;
thresh=0.01; beats=0; 
% t=0; rate=[];
for i=1:size(opav,1)-1
    %nt=t;
    if(opav(i)>=thresh)&&(opav(i+1)<thresh)
        beats=beats+1;
%         t=i;
%         rate(beats)=1/abs(nt-t);
    end
   
end
rate=2*beats*60*100/size(opav,1);
%  avgrate=mean(rate(2:end));
