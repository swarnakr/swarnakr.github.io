function Irectified = Affine2(I)
    figure(5), imshow(I);

    %Choose three points with EQUAL length ratios 
    
    Knownpoints = [0 1 2; 1 1 1]; %change to [0 1 1; 1 1 1] if in doubt
    vanpts = [];
    for i=1:2
        pointset1 = ginput(3)';
        length1 = sum((pointset1(:,1)-pointset1(:,2)).^2).^0.5
        length2 = sum((pointset1(:,2)-pointset1(:,3)).^2).^0.5
        points1 = [0 length1 length1+length2; 1 1 1];

        %after solving mathematically on paper
        h1= (length1 * (length1 + length2))/ 2*length2;
        h3 = (length1 - length2)/ 2*length2;
        h2 = 0; h4 = 1;
        H = [h1 h2; h3 h4]; disp(H)
        
        vanpt = H * [1 0]';
        vanpts = [vanpts vanpt];
    end
    vanpts = [vanpts; [1 1]];
    l = cross(vanpts(:,1), vanpts(:,2));  disp(l')
    H = [1 0 0; 0 1 0; l']; disp(H)
    
    affine_tform = maketform('projective', H');
    Irectified  = imtransform(I, affine_tform,'FillValues', 0, 'Size', size(I));

    figure(10);
    imshow(Irectified), title('Result of Affine Recitification: length ratios');
end