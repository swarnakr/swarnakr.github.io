function Irectified = DualConic(I)
    figure(5), imshow(I);
    orthPairs = [];

    for i=1:5
        point1 = ginput(2);
        point1 = [point1'; [1 1]];
        l1 = cross(point1(:,1), point1(:,2));
        
        point2 = ginput(2);
        point2 = [point2'; [1 1]];
        m1 = cross(point2(:,1), point2(:,2));
        orthPairs = cat(3,orthPairs,[l1 m1]);
    end
    
    %Criteria to be satified for orthogonal lines
    Cmat = [];
    for i=1:5
        l= orthPairs(:,1,i);
        m= orthPairs(:,2,i);
        Ctemp = [l(1)*m(1), (l(1)*m(2)+l(2)*m(1)), l(2)*m(2), (l(1)*m(3)+l(3)*m(1)), (l(2)*m(3)+l(3)*m(2)), l(3)*m(3) ];
        Cmat = [Cmat; Ctemp];
    end
    
    c = null(Cmat);
    C = [c(1) c(2)/2 c(4)/2; c(2)/2 c(3) c(5); c(3) c(5) c(6)];
    
    [U,D,V] = svd(C);
    H = U;
    
    projective_tform = maketform('projective', H');
    Irectified = imtransform(I, projective_tform,'FillValues', 0, 'Size', size(I));
    
    figure(10);
    imshow(Irectified), title('Result Recitification using Dual Conic');


end