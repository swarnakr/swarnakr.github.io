function [I_out, T] = rectifyImage(opr, I_in, hFig, hFigRes)
% RECTIFYIMAGE Perform image recrification.  
%   [I_out, T] = rectifyImage(opr, I_in, hFig, hFigRes) applies the 
%   recrification specified by opr to the image I_in. This image is loaded
%   into the figure specifed by hFig which the user must then use to
%   identify the required information to perform the rectification. The 
%   result of the rectification is then loaded into the figure described
%   by hFigRes, the resulting image is returned in I_out, and the
%   transformation applied is returned in T.
figure(hFig);

%%  Utility functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Normalize a homogeneous point so that its last component is 1
function n = normalize(p)
    n = p / p(3);
end

% Find the line, l, through two points A and B
%  l must satisfy l*A=0 and l*B=0, so we need l such that
%  [A B] * l = 0, which we may find using the built in null() function.
%  This happens to simplfy to the cross product of A and B
function l = lineFromPts(a,b)
    %l = null([a'; b']);
    l = cross(a,b);
end
function l = lineFromPtsAB(ab)
    %l = null(ab');
    l = cross(ab(:,1), ab(:,2));
end

% Given a line l, and a set of x coordantes X, find the corresponding y's
function Y = yForX(l, X)
    Y = -l(1)/l(2)*X - l(3)/l(2);
end

% Apply a transformation to a line
function m = transformLine(l, T)
    T_inv = inv(T);
    m = T_inv' * l;
end

% Draw a line all the way accross an image
function addLine(l, color)
    pos = get(gcf,'Position');
    widthX = pos(3);
    X = [0 widthX];
    Y = yForX(l, X);
    line(X,Y, 'Color', color);
end

% Find the intersection point, p, of two lines
%  p must satisfy p*l1=0 and p*l2=0, so we need p such that
%  [l1 l2] * p = 0, which we may find using the built in null() function.
%  This happens to reduce to the cross product of l1 and l2 
function p = intersectLines(l1, l2) 
    %p = normalize(null([l1'; l2']));
    p = normalize(cross(l1,l2));
end

% Use ginput to get a matrix of N homogeneous points
function hPts = getHPts(n)
    ePts = ginput(n)';
    hPts = [ePts; ones(1,length(ePts))];
end
    
% Use ginput to get two points and return the line connecting them
function l = getLine()
    pts = getHPts(2);
    l = lineFromPtsAB(pts);
end

% Construct a rotation matrix for the given angle
function R = rot(angle) 
   R = [cos(angle) -sin(angle); sin(angle) cos(angle)];
end

% Do Cholesky decomposition, A = KK' where K is upper triangular.
% There is also a builtin chol() function which does the
% decomposition as A = LL' where L is lower triangular.
function K = cholesky(A)
    
    % Do eigenvalue decomposition
    [U,D] = eig(A);
    if sum(diag(D) < 0) > 0 || isreal(D) == 0
        error('cholesky: matrix not positive definite:\nA=%s\nD=%s\n', ...
              mat2str(A,4), mat2str(D,4));
    end
        
    % do the decomposition
    E = sqrt(D);
    V = U*E;
    t = atan(V(2,1) / -V(2,2));
    K = V*rot(t);
end


%% Affine rectification
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [I_affine, H] = rectifyAffine(hFig, I_distort, hFigRes)
    figure(hFig);
    
    % Have the user select two parallel lines, and find their intersection
    l11 = getLine(); addLine(l11, 'red');
    l12 = getLine(); addLine(l12, 'red');
    px1 = intersectLines(l11, l12);
    disp('Parallel lines lA ='), disp(l11'), disp(' and lB ='), disp(l12')
    disp('intersect at point p1 ='), disp(px1')

    % And a second set, and their intersection
    l21 = getLine(); addLine(l21, 'blue');
    l22 = getLine(); addLine(l22, 'blue');
    px2 = intersectLines(l21, l22);
    disp('Parallel lines lA ='), disp(l21'), disp(' and lB ='), disp(l22')
    disp('intersect at point p2 ='), disp(px2')

    % Now compute the line joining the two intersection points, this is the
    % image of the line at infinity.
    lx = lineFromPts(px1, px2);
    disp('The image of the line at infinity (through p1 and p2) =')
    disp(lx')

    % Setup the transform to map the line back to (0, 0, 1)
    H = [1 0 0; 0 1 0; lx'];
    disp('The rectifiying transform, H, is:'), disp(H)

    % Apply the transform to create the rectified image
    affine_tform = maketform('projective', H');
    I_affine  = imtransform(I_distort, affine_tform, ...
                            'FillValues', 0, 'Size', size(I_distort));

    % Show the results
    % The transformed lines are now disabled, they were not interesting...
    figure(hFigRes), clf, imshow(I_affine), title('Affine rectification');
    % addLine(transformLine(l11, H), 'red');
    % addLine(transformLine(l12, H), 'red');
    % addLine(transformLine(l21, H), 'blue');
    % addLine(transformLine(l22, H), 'blue');
end
 

%% Metric rectification
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [I_metric, T] = rectifyMetric(hFig, I_affine, hFigRes)
    figure(hFig);
    
    % Get a pair of orthogonal lines from the user
    l1 = getLine(); addLine(l1, 'red');
    m1 = getLine(); addLine(m1, 'red');
    disp('Orthogonal lines l1 ='), disp(l1'), disp(' and m1 ='), disp(m1')
   
    % And a second pair
    l2 = getLine(); addLine(l2, 'blue');
    m2 = getLine(); addLine(m2, 'blue');
    disp('Orthogonal lines l2 ='), disp(l2'), disp(' and m2 ='), disp(m2')
    
    % Proceed with the rectification technique outlined in example
    % 2.26 of the Multiple View Geometry by Hartley and Zisserman.
    % Setup the orthogonality constraint on the image of the dual conic.
    cS = [l1(1)*m1(1), (l1(1)*m1(2)+l1(2)*m1(2)), l1(2)*m1(2);
          l2(1)*m2(1), (l2(1)*m2(2)+l2(2)*m2(1)), l2(2)*m2(2)];
    disp('The orthogonality constraint is X*s=0, where X = '), disp(cS);

    % Find the vector the satisfies the constraint
    s = null(cS);
    disp('This is satisfied by s ='), disp(s');

    % Construct S = K*K'
    S = [s(1), s(2); s(2), s(3)];
    disp('Thus S = K*K'' ='), disp(S);

    % Apply cholesky to get the final transform (K)
    K = cholesky(S);
    disp('By the Cholesky decomposition, K ='), disp(K);

    % Make it a valid transform for homogeneous coords
    T = [K(1,:) 0; K(2,:) 0; 0 0 1];
    disp('The rectifying transform is'), disp(T);

    % Create the transform and apply it
    metric_tform = maketform('affine', T');
    I_metric = imtransform(I_affine, metric_tform,...
                           'FillValues', 0, 'Size', size(I_affine));

    % Show the results
    % The transformed lines are now disabled, they were not interesting...
    figure(hFigRes), clf, imshow(I_metric), title('Metric rectification');
    % addLine(transformLine(l1, T), 'green');
    % addLine(transformLine(m1, T), 'green');
    % addLine(transformLine(l2, T), 'yellow');
    % addLine(transformLine(m2, T), 'yellow')
end

%% Apply the requested rectification
switch opr
    case 'affine'
        [I_out, T] = rectifyAffine(hFig, I_in, hFigRes);
    case 'metric'
        [I_out, T] = rectifyMetric(hFig, I_in, hFigRes);
    case 'both'
        I_affine = rectifyAffine(hFig, I_in, hFigRes);
        [I_out, T] = rectifyMetric(hFigRes, I_affine, hFigRes);
    otherwise
        error(['rectifyImage: opr must be ''affine'', ''metric'','...
               ' or ''both''']);
end

end