function [Irectified, T] = Metric(I)
    figure(5), imshow(I);
    
    %Line at infinity from intersection of 2 Orthogonal lines
    
    %2nd pair of orthogonal lines
    point1 = ginput(2);
    point1 = [point1'; [1 1]];
    l1 = cross(point1(:,1), point1(:,2));
    
    point2 = ginput(2);
    point2 = [point2'; [1 1]];
    m1 = cross(point2(:,1), point2(:,2));
    
    %2nd pair of orthogonal lines
    point1 = ginput(2);
    point1 = [point1'; [1 1]];
    l2 = cross(point1(:,1), point1(:,2));
    
    point2 = ginput(2);
    point2 = [point2'; [1 1]];
    m2 = cross(point2(:,1), point2(:,2));
      
    %Criteria to be satified for orthogonal lines
    Smat = [l1(1)*m1(1), (l1(1)*m1(2)+l1(2)*m1(1)), l1(2)*m1(2);
          l2(1)*m2(1), (l2(1)*m2(2)+l2(2)*m2(1)), l2(2)*m2(2)];
    
    s = null(Smat);
    S = [s(1), s(2); s(2), s(3)];
    K = chol(S);
%     [U,D] = eig(S);
%     Droot = sqrt(D);
%     V = U*Droot;
%     theta = atan(V(2,1) / -V(2,2));
%     R = [cos(theta) -sin(theta); sin(theta) cos(theta)];
%     K = V*R;
    
    T = [K(1,:) 0; K(2,:) 0; 0 0 1];
    
    metric_tform = maketform('affine', T');
    Irectified = imtransform(I, metric_tform,'FillValues', 0, 'Size', size(I));
    
    figure(10);
    imshow(Irectified), title('Result of Metric Recitification');


end
