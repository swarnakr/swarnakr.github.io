 I=imread('./images/image1.gif');
%  Irectified1 = Affine1(I);
% % Irectified2 = Affine2(I);
% Irectified3 = Metric(Irectified1);
 Irectified4 = DualConic(I);