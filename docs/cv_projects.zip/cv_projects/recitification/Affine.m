function Irectified = Affine1(I)
    figure(5), imshow(I);
    TwopInf = [];
    %Line at infinity from intersection of 2 parallel lines
    for i=1:2
        point1 = ginput(2);
        point1 = [point1'; [1 1]];
        line1 = cross(point1(:,1), point1(:,2));

        point2 = ginput(2);
        point2 = [point2'; [1 1]];
        line2 = cross(point2(:,1), point2(:,2));

        pInftemp = cross(line1,line2);
        pInf = pInftemp / pInftemp(3);
        TwopInf = [TwopInf pInf];

    end
   
    l = cross(TwopInf(:,1), TwopInf(:,2));  disp(l')
    H = [1 0 0; 0 1 0; l']; disp(H)

    affine_tform = maketform('projective', H');
    Irectified  = imtransform(I, affine_tform,'FillValues', 0, 'Size', size(I));

    figure(10);
    imshow(Irectified), title('Result of Affine Recitification: intersection of 2 ||ll lines');
end
 

