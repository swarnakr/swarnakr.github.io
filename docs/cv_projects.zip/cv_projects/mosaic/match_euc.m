% num = match(image1, image2)
%
% This function reads two images, finds their SIFT features, and
%   displays lines connecting the matched keypoints.  A match is accepted
%   only if its distance is less than distRatio times the distance to the
%   second closest match.
% It returns the number of matches displayed.
%
% Example: match('scene.pgm','book.pgm');

function [input_point, base_point] = match(image1, image2,fno,sno,thresh,dthresh)

% sprintf('img%d.desc',fno)
% sprintf('img%d.desc',sno)

[des1 feat1 loc1]=loadFeatures(sprintf('img%d.desc',fno));
[des2 feat2 loc2]=loadFeatures(sprintf('img%d.desc',sno));
% % Find SIFT keypoints for each image
% [im1, des1, loc1] = sift(image1);
% [im2, des2, loc2] = sift(image2);

% For efficiency in Matlab, it is cheaper to compute dot products between
%  unit vectors rather than Euclidean distances.  Note that the ratio of 
%  angles (acos of dot products of unit vectors) is a close approximation
%  to the ratio of Euclidean distances for small angles.
%
% distRatio: Only keep matches in which the ratio of vector angles from the
%   nearest to second nearest neighbor is less than distRatio.
distRatio = 0.75;   

% For each descriptor in the first image, select its match to second image.
des2t = des2';     % Precompute matrix transpose


for i = 1 : size(des1,2)
    dists=[];
    for j = 1 : size(des2,2)
      dists=[dists sqrt(sum((des1(:,i)-des2(:,j)).^2))];       
    end
    [vals,indx] = sort(dists); 
   % Check if nearest neighbor has angle less than distRatio times 2nd.
   if vals(1)<thresh & (vals(1) < distRatio * vals(2))
      matching(i) = indx(1);
   else
      matching(i) = 0;
   end
end

I1=image1; I2=image2;
% Create a new image showing the two images side by side.
im3 = appendimages(I1,I2);

% Show a figure with lines joining the accepted matches.
figure('Position', [100 100 size(im3,2) size(im3,1)]);
colormap('gray');
imagesc(im3);
hold on;
cols1 = size(I1,2);
input_point=[]; base_point=[];
for i = 1: size(des1,1)
  if (matching(i) > 0)
    input_point=[input_point; loc2(matching(i),2) loc2(matching(i),1)];
    base_point=[base_point; loc1(i,2) loc1(i,1)];
    line([loc1(i,1) loc2(matching(i),1)+cols1],[loc1(i,2) loc2(matching(i),2)],'Color', 'c');
  end
end
hold off;
bothpts=unique(cat(2,base_point,input_point),'rows');

base_point= bothpts(:,[2 1]);
input_point=bothpts(:,[4 3]);

dist_pts=squareform(pdist(base_point));
Ldist=tril(dist_pts);
[ub v r]=find(Ldist>0 & Ldist<dthresh);

% base_points= feat1
% input_points= feat2

dist_pts=squareform(pdist(input_point));
Ldist=tril(dist_pts);
[ui v r]=find(Ldist>0 & Ldist<dthresh);
unique([ub; ui])
bothpts(unique([ub; ui]),:)=[];

base_point= bothpts(:,[2 1]);
input_point=bothpts(:,[4 3]);

%%%%%%%%%%%%%%%%%%%%%
%%%display again

imagesc(im3);
hold on;
cols1 = size(I1,2);
for i = 1: size(base_point,1)
  line([base_point(i,1) input_point(i,1)+cols1],[base_point(i,2) input_point(i,2)],'Color', 'c');
  
end

% [x,y] = ginput(6)
% hold off;
% finalpts=[];
% for i=1:6
% [u v r]=find (base_points(:,1)>(x(i)-2) & base_points(:,1)<(x(i)+2) & base_points(:,2)>(y(i)-2) & base_points(:,2)<(y(i)+2))
% finalpts=[finalpts; bothpts(u,:)];
% end

% base_points= finalpts(:,[2 1]);
% input_points=finalpts(:,[4 3]);

num = sum(matching > 0);
fprintf('Found %d matches.\n', num);




