img1=imread('img1.png');
img2=imread('img2.png');

mosaic(img1,img2,1,2,100,30);

img3=imread('img3.png');
img4=imread('img4.png'); 

mosaic(img3,img4,3,4,100,30);

img5=imread('img5.png');
img6=imread('img6.png');

mosaic(img5,img6,5,6,200,10);