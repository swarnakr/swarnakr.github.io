 function mosaic(img1,img2,fno,sno,thresh,dthresh)
% 
[base_points,input_points]=match_euc(img1, img2,fno,sno,thresh,dthresh);
% cpselect(rgb2gray(img1), rgb2gray(img2));
% pause;
TFORM = cp2tform(input_points, base_points, 'affine');
%[TFORM, input_points, base_points, input_points_bad, base_points_bad]= cp2tform(input_points, base_points, 'piecewise linear');

[trans xdata ydata] = imtransform(img1, TFORM);
[n o b] = size(trans);
[l m z] = size(img2);
 
imshow(trans);
figure; 
imshow(img2);
if(xdata(1)<0)
    xdisp = -xdata(1) + 1;
    xdisp = round(xdisp);
    
    if(ydata(1)<0)
     ydisp = round(-ydata(1) + 1);
     imgsizex = max(n, l+ydisp-1);
     imgsizey = max(o, m+xdisp-1);
 
     canvas = uint8(zeros(imgsizex, imgsizey,3));
     canvas1 = uint8(zeros(imgsizex, imgsizey,3));
     canvas2 = uint8(zeros(imgsizex, imgsizey,3));
     
     canvas1(1:(n), 1:o, 1:z) = trans;
     canvas2(ydisp:(l+ydisp-1), xdisp:(m+xdisp-1), 1:z)= img2;
 
    else
     ydisp = round(1+ydata(1));
     imgsizex = max(n+ydisp-1, l);
     imgsizey = max(o, xdisp+m-1);
 
     canvas = uint8(zeros(imgsizex, imgsizey,3));
     canvas1 = uint8(zeros(imgsizex, imgsizey,3));
     canvas2 = uint8(zeros(imgsizex, imgsizey,3));
     
     canvas1(ydisp:(ydisp+n-1), 1:(o), 1:z) = trans;
     canvas2(1:(l), xdisp:(xdisp+m-1), 1:z)= img2;
 
    end    
else
    xdisp = xdata(1) + 1;
    xdisp = round(xdisp);
    
    if(ydata(1)<0)
     ydisp = round(-ydata(1) + 1);
     imgsizex = max(n, l+ydisp-1);
     imgsizey = max(o+xdisp-1, m);
 
     canvas = uint8(zeros(imgsizex, imgsizey,3));
     canvas1 = uint8(zeros(imgsizex, imgsizey,3));
     canvas2 = uint8(zeros(imgsizex, imgsizey,3));
     
     canvas1(1:(n), xdisp:(o+xdisp-1), 1:z) = trans;
     canvas2(ydisp:(ydisp+l-1), 1:(m), 1:z)= img2;
 
    else
     ydisp = round(1+ydata(1));
     imgsizex = max(n+ydisp-1, l);
     imgsizey = max(o+xdisp-1, m);
 
     canvas = uint8(zeros(imgsizex, imgsizey,3));
     canvas1 = uint8(zeros(imgsizex, imgsizey,3));
     canvas2 = uint8(zeros(imgsizex, imgsizey,3));
     
     canvas1(ydisp:(n+ydisp-1), xdisp:(xdisp+o-1), 1:z) = trans;
     canvas2(1:(l), 1:(m), 1:z)= img2;
 
    end    
end    
     canvassub = imsubtract(canvas1, canvas2);
     canvas = imadd(canvassub,canvas2);
     
     output=sprintf('img%d.png',sno+1);
     imwrite(canvas, output);
figure;
imshow(canvas);