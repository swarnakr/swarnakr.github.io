function [featdes feat2 loc]=loadFeatures(file)
fid = fopen(file, 'r');
dim=fscanf(fid, '%f',1);
nb=fscanf(fid,'%f',1);
feat = fscanf(fid, '%f', [5+dim, inf]);
loc=feat(1:5,:)';
featdes=feat(6:end,1:nb);
feat2=loc(nb+1:end,1:3);
fclose(fid);