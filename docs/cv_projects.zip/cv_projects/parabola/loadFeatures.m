function [look]= loadFeatures(file)
fid = fopen(file, 'r');
cpt=fscanf(fid, '%f',[1 inf]);
% nb=fscanf(fid, '%d',1);
% feat = fscanf(fid, '%f', [5+dim, inf]);
sz=size(cpt,2)/4;
look(:,1)=cpt(1,1:sz);
look(:,2)=cpt(1,sz+1:2*sz);
fclose(fid);