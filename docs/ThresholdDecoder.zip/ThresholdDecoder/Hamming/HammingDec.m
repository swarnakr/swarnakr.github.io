function e = HammingDec(m,RV)

k = 2^m-m-1; n = 2^m-1;
[H G] = hammgen(m); % hamming(15,11,3)
POrig=H(:,m+1:end);
s =  mod(mod(POrig*RV(m+1:end)',2) - RV(1:m)',2);
% P = POrig;

for bit  = 1:k
    P = circshift(POrig,[0 1-bit]);
    wtsInit = sum(P);
    evenOrOddInit = mod(wtsInit,2);
    pIndInit = ones(1,size(P,2));
       
    if ~evenOrOddInit(1) % if first col is even
        [P pIndInit eSum]= ModifyP(P,m,pIndInit,s',1); %no need for circular shift on syndrome
    else
        [P pIndInit eSum]= ModifyP(P,m,pIndInit,s',0);
    end
    %Note: when FIRST col starts out to be even it will stay even. similarly,
    %it will stay odd if it's odd in the beginning. there will bve no loop
    %intersection
    validPCol = find(pIndInit==1);
    error = TwoStepOrth(P,eSum);
    if validPCol(1)==1
        e(bit) = error;
    else
        e(bit) = 0;
    end
end

end


function [P pIndInit eSum]= ModifyP(P,m,pIndInit,eSum,evenBit)

for i=1:m-3
    
    if evenBit
        eSum = ElimEvenCols(P,eSum);
    else
        [dummy P eSum] = ElimEvenCols(P,eSum);
    end
    
    wts = sum(P);
    if evenBit
        evenOrOdd = mod(wts,2);
    else
        evenOrOdd = ~mod(wts,2);
    end
        
    pInd = 1:size(P,2);
    pModInd = pInd(~evenOrOdd);

    [dummy map] = find(pIndInit==1);
    delSet = map(~~evenOrOdd);
    pIndInit(delSet) = 0;
    
    PMod = P(:,pModInd);
    u = find(PMod(:,1)==0);
    if isempty(u)
        uNew = find(PMod(:,1)==1);
        if size(uNew,1) > 2
            u = uNew;
        end
    end
    
    PMod(u(end),:) = []; %Discard any one sum
    P=PMod;
    eSum(u(end)) = [];
end

end

%Checking the orthogonality of rows and sums
function [eSumNew P eSumOdd] = ElimEvenCols(P,eSum) %only for odd case

pInd = 1:size(P,1);
eVecEmpty = zeros(1,size(P,2));

for i=1:size(P,1)
    
    remInd = setdiff(pInd,i);
    remSum = mod(sum(P(remInd,:)),2);
    onePos1 = find(remSum == 1); %orthogonal on positions where weight of col of P is even AND ith row contains a 1
    onePos2 = find(P(i,:)==1);
    orth(i,:) = intersect(onePos1,onePos2); %gives common orth bits
    
    checksums(i,1) = eSum(i);
    checksums(i,2) = mod(sum(eSum(remInd)),2);
    
    eSumNew(i) = all(checksums(i,:)); %simpler majority decoding rule since there are only 2 checks
    eVec(i,:) = eVecEmpty; eVec(i,orth(i,:))=1;
end
    P = mod(P + eVec,2);
    eSumOdd = mod(eSum + eSumNew,2);
end

%Final 2- step orthogonalization
function error = TwoStepOrth(P,eSum) %only for odd case

pInd = 1:size(P,1);
eVecEmpty = zeros(1,size(P,2));
% eFinalSum = zeros(1,size(eSum,2));
for i=1:size(P,1)
    
    onePos1 = find(P(i,:) == 1); %orthogonal on positions where weight of col of P is even AND ith row contains a 1
    onePos2 = find(P(mod(i,3)+1,:) ==1);
    orth(i,:) = intersect(onePos1,onePos2); %gives common orth bits
    
    checksums(1,1) = eSum(i);
    checksums(1,2) = eSum(mod(i,3)+1);
    
    eSumNew(i) = all(checksums(1,:)); %simpler majority decoding rule since there are only 2 checks
    eVec(i,:) = eVecEmpty; eVec(i,orth(i,:))=1;
    
end


for i=1:size(orth,1)
   if all(orth(i,:)~=1) 
       allVec = all(P(:,orth(i,:))'); %if one was not an orth bit and cols in Pone haven't been removed;
       if any(allVec)
           sizeRep = size(P(~~allVec,:),1);
           errorMat = repmat(eVec(i,:),sizeRep,1);
           P(~~allVec,:) =mod(P(~~allVec,:) + errorMat,2); %eVec corres to the set orth
           eFinalSum(~~allVec) = mod(eSum(~~allVec) +  repmat(eSumNew(i),1,sizeRep),2);
       end
   end
end

u = find(P(:,1)==1);
Pone = P(u,:);

if ~exist('eFinalSum')
    if orth(:,1)==1
        error = all(eSumNew); %CHECK CORRECTNESS
    else
        disp('error because all bits in 1st row are one');
    end
    
else
    eFinalSum = eFinalSum(u);
    error = all(eFinalSum);
end

end
