m = 4; k = 2^m-m-1; n = 2^m-1;
msg = [1 0 1 1 0 1 0 0 1 1 0];
% msg = [1 0 1 1 0 1 0 0 1 1 0 zeros(1,5) 1 1 0 1 zeros(1,6)];
code = encode(msg,n,k);
% infoCode = code(m+1:end);

for i=1:k
    noise = zeros(1,n);
    noise(m+i) = 1; %d=3: only 1 errors possible! e(4)
    RV = mod(code + noise,2);
    
    e = HammingDec(m,RV);
    
    u=find(e-noise(m+1:end)>0);
    if isempty(u)
        disp('Decoding Suceess');
    else
        disp('Decoding failure');
    end
    
end