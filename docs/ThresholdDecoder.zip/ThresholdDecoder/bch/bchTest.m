load('H15_5_7.mat');
n=15; k=5; d = 7; %BCH(15,5,7) n-k =10;
t=3;
msg = [1 0 1 1 0];
P = H(:,1:k);
%%%%


G = gen2par(H);
code1 = mod(msg*G,2);
code = encode(msg,n,k,'linear',G);

combos = combntns(1:5,t);
for j=1:size(combos,1)
    noise = zeros(1,n);
    noise(combos(j,:)) = 1;
    RV = mod(code + noise,2);
        
    e = bchThresh(P,RV,d,k);
    
    u = find(e-noise(1:k)>0);
    if isempty(u)
        disp('Decoding Suceess');
    else
        disp('Decoding failure');
    end
        
end
%%%%%%%%%%%%%%%%%%%%%%%%
% Trial 
% P = [1 0 1 0 1;
% 1 1 1 1 1;
% 1 1 0 1 0;
% 0 1 1 0 1;
% 1 0 0 1 1;
% 1 1 1 0 0;
% 0 1 1 1 0;
% 0 0 1 1 1;
% 1 0 1 1 0;
% 0 1 0 1 1];
% 
% H=[P eye(10)];


%%%%%%%%%%%%%%%%%%%%%%%%
% %other generators
% n=31; k=21;d=5; t=2;
% genpoly = bchgenpoly(n,k);
%  genpoly=[1 1 1 0 1 1 0 1 0 0 1];
% [H,G] = cyclgen(31,genpoly);
% [G,P]=systematize(G);
% 
% msg = [1 0 1 1 0 zeros(1,10) 1 0 1 0 0 1];
% 
% P = H(:,n-k+1:end);
% %%%%%