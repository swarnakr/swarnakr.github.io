function e = bchThresh(P,RV,d,k)

% R = size(H,1); %R=N-K
% N = size(H,2);
% P = H(:,1:R-1);

K=size(P,1);
n = size(P,2);

s =  mod(mod(P*RV(1:k)',2) - RV(k+1:end)',2);
%% Starting Loop
shiftInd = 0; l =1; errorVecSet =[];
J= d-1; orthSet = []; k=1;

for i=1: n - 2^(l-1)
    [checkSums errorVec l] = GetParityChecks(P,K,s,J,l,shiftInd);
    errorVecSet = [errorVecSet; errorVec];
    shiftInd = shiftInd +1;
end
    
[errorVecCombMat errorSumCombMat] = GetCombErrors(errorVecSet,2);

%% n - 1 step
checkSumsFinal=[];
for i=2:size(errorVecCombMat,1)
    modPar = xor(repmat(errorVecCombMat(i,:),size(P,1),1),P);
    u = find(modPar(:,1) ==1);
    oneVals = any(modPar(u,2:end),2);
    parRow = u(~oneVals);
    orthParCheck = P(parRow,:);    
    checkSumsFinal = [checkSumsFinal; mod(s(parRow) + errorSumCombMat(i),2)];
end

e(1) = MajLogicVote(sum(checkSumsFinal),J);

%% Remaining error bits

[errorVecCombMat errorSumCombMat] = GetCombErrors(errorVecSet,1);
firstE = zeros(1,n); firstE(1)=1;
%here we suppose that weight of each error vector = 2; For generalizing
%this should actually be confirmed using a find.
errorsNew = xor(errorVecCombMat,repmat(firstE,size(errorVecCombMat,1),1));
errorSumNew = mod(errorSumCombMat + e(1),2);
for i=2:n
    [u v] = find(sum(errorsNew,2) == 1 & errorsNew(:,i) == 1);
    if ~isempty(u)
        e(i) = errorSumNew(u);
    else
        [u1 v1] = find(errorsNew(:,1) == 0 & errorsNew(:,i) == 1); %pos one must've orignally be present
       
        for j=1:size(u1,1)
            [dummy oneCol] = find(errorsNew(u1(j),:)==1); %find all other one positions
            if all(oneCol <= i)
                restOne = oneCol(oneCol< i);  % all pos except one and i
                allElse = setdiff(1:n,restOne);
                u2 = all(errorVecCombMat(:,restOne)'==1) & all(errorVecCombMat(:,allElse)'==0);
                e(i) = mod(errorSumNew(u1(j)) + errorSumCombMat(u2),2);
                continue;
            end
        end
        
        if ~exist('u2')
            disp('No appropriate error sum found');
        end

    end
    
end

end

%%
function [checkSums errorVec l] = GetParityChecks(P,K,s,J,l,shiftInd)

[Pcomb szArray]= GenerateComb(P,K);
n = size(P,2);

%L step orthogonalization
orthSet = [];

orthParChecks ={};
errorVecEmpty = zeros(1,n);

%Generating choseInd tree structure
choseInd(1,:) = errorVecEmpty; choseInd(1,1) = 1;
choseInd(2,:) = errorVecEmpty; choseInd(2,1:2) = 1;
choseInd(3,:) = errorVecEmpty; choseInd(3,1:4) = 1;
%%%%%%%
choseInd = circshift(choseInd,[0 shiftInd]);

while l<4 %3 step majority logic 
    [dummy ind] = find(choseInd(l,:) == 1);
    k=1;
    while k<3 && isempty(orthSet) %iterating through all combs of P to get J parity checks
       
        allPcomb=cell2mat(Pcomb(1:k,1));
        oneVals = all(allPcomb(:,ind),2);
        lStepMap = find(oneVals==1);
        remCols = setdiff(1:n,ind);
        remP = allPcomb(oneVals==1,remCols); 
        orthSet = CheckOrthogonalityNew(remP,J); %use to break out of loop
        k=k+1;
        
    end


    if ~isempty(orthSet)
        indPComb0 = lStepMap(orthSet);
        set1 = indPComb0(indPComb0 <= szArray(2));
        orthParChecks{1} = P(set1,:); %must iterate through k if k is more than 2 
        checkSums = s(set1);
        
        [~,indPComb1] =ismember(indPComb0(indPComb0 > szArray(2)),Pcomb{2,2}); %if made generate Pcomb{k,2}
        indP = Pcomb{2,3}(indPComb1,:);
        set2Sums = 0;
        for i=1:size(indP,2)
            orthParChecks{1,2}(:,:,i) = P(indP(:,i),:);
            set2Sums = mod(set2Sums + s(indP(:,i)),2);
        end
        
        checkSums = [checkSums; set2Sums];
        errorVec{1} = errorVecEmpty;
        errorVec{1}(ind) = 1;        
        errorVec{1,2} = MajLogicVote(checkSums,J);
        break; %don't have to proceed through remaining stages if 1 set of error is found
    end
    l=l+1;
end

end

%%
function error = MajLogicVote(checkSums,J)
sumVal = sum(checkSums);
if sumVal > floor(J/2)
    error = 1;
else
    error = 0;
end

end
%%

function [Pcomb szArray] = GenerateComb(P,K,maxk) %second parameter hardcoded for now

if nargin <3
maxk=2;
end

Pcomb={};
szArray(1) = 0;
for k=1:maxk
    comb = nchoosek((1:K),k);        
    szPcomb = szArray(k);
    
    for i=1:size(comb,1)
        Pcomb{k,1}(i,:) = mod(sum(P(comb(i,:)',:),1),2);
        Pcomb{k,2}(i,:) = i+szPcomb;
        Pcomb{k,3}(i,:) = comb(i,:);
    end
    
    szArray(k+1) = size(Pcomb{k},1);
end

end

%%

function [errorVecCombMat errorSumCombMat] = GetCombErrors(errorVecSet,start);
errorVecMat = cell2mat(errorVecSet(start:end,1));
errorSumMat = cell2mat(errorVecSet(start:end,2));

[errorVecComb szArray] = GenerateComb(errorVecMat,size(errorVecMat,1)); %No need for comb of 3 here
[errorSumComb szArray] = GenerateComb(errorSumMat,size(errorSumMat,1)); %Checked that the rows correspond

errorVecCombMat = cell2mat(errorVecComb(:,1));
errorSumCombMat = cell2mat(errorSumComb(:,1));
end