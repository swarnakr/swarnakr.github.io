function newP = updateP(P,errorVectors,l)

%combTree{1,l-1}
lPrev  = 2^(l-2);%previous level has these many terms
combPrev = comb(1:lPrev);  %combinations in the previous level of the tree
rows = find(P(:,combPrev) ==1);
Pupdate(:,comb(:,i)) = P(rows,:); %update P- update original P only- not all possible combinations of P

xor(P,errorVecors);

end