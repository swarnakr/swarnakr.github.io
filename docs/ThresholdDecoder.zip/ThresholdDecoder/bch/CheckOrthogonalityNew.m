function orthSetInd = CheckOrthogonalityNew(remP,J)

% [orthSet maxSz maxInd] = checkOrthogonality(remP,J);

% if maxSz >= J %implies this condition - && maxInd
%     orthSetNew = orthSet{maxInd};
%     while size(orthSetNew,1) > 1
%         orthSet = checkOrthogonality(remP,J,orthSetNew);
%     end
% end

orth = remP * remP';
orth = orth+diag(-diag(orth));
commonOrth = {}; validInd = [];

for i=1:size(remP,1)
    commonOrth{i} = find(orth(i,:)==0);
    if size(commonOrth{i},2)>=J
        validInd = [validInd; i];
    end
end

if size(validInd,1) >= J
    orthSetInd = intersectn(commonOrth{:},validInd,J);
else
    orthSetInd = [];
end

if size(orthSetInd,2) <J
    orthSetInd = [];
end

end

