function out = intersectn(varargin)

% INTERSECTN functions similarly to INTERSECT, but has some added
% flexibility. For example, if you input three arrays and want to find
% items that are in at least two of them, INTERSECT is incapable of doing
% this, but INTERSECTN will do it.
%
% OUT = INTERSECTN(IN1,IN2,...,MATCHES)
%
% Inputs: IN1,IN2,... are cell arrays of strings or numerical vectors.
%         MATCHES is a scalar, the number of matches that are required.
%
% For example, if you have three sets of fruit names, and you want to
% return any fruits that show up in at least two of these sets, use:
%    OUT = INTERSECTN(IN1,IN2,IN3,2)
%
% Example:
%    fruit{1} = {'apple','banana','cherry','orange'};
%    fruit{2} = {'apple','cherry','lemon','tangerine'};
%    fruit{3} = {'apple','lemon','lime','peach'};
%    fruit{4} = {'apple','lemon','orange','coconut'};
%
%    out = intersectn(fruit{:},4)
%        returns: 'apple'
%
%    out = intersectn(fruit{:},3)
%        returns: {'apple','lemon'}
%
%    out = intersectn(fruit{:},2)
%        returns: {'apple','cherry','lemon','orange'}
%
% Copyright (C) 2011 Jeremy Brower.
% jeremy.brower@gmail.com


if ~isnumeric(varargin{nargin})
    error('Last input argument to INTERSECTN must be a scalar.')
end

if varargin{nargin} > nargin-1
    error('Group size cannot be larger than the number of groups.')
end

for j = 1:nargin-2
    v{j} = varargin{j};
end

validInd = varargin{nargin-1};
n = nargin-2;             %-- # of input sets
k = varargin{nargin};     %-- # of required matches
c = combntns(validInd,k);        %-- possible combinations of n & k
updateSize = size(c,1);         %-- # of combinations of n & k
removalFlag = 0;
setFlag = 0;
i=1;

while i <= updateSize && ~setFlag
    sets{i} = v{c(i,1)};
    removalFlag = 0;
    for j = 2:k
        if i<= updateSize
            sets{i} = intersect(sets{i},v{c(i,j)}); %set finally contains the indices common to the combination specified in c(i,:)
            if size(sets{i},2)<k
                [row col] = find(c== c(i,1));
                [row1 col1] = find(c== c(i,j));
                commonRows = intersect(row,row1); %previous rows must not be removed
                
                if ~isempty(commonRows)
                    removalFlag = 1 + removalFlag; % to ensure that if there was even one removal in the loop, it should be set
                else
                    removalFlag = 0 + removalFlag;
                end
                
                c(commonRows,:) = [];
                updateSize = size(c,1);
            else
                removalFlag = 0 + removalFlag;
                
            end
        end
          
    end
    
    numOrth = sum(ismember(c(1,:),sets{i})); % # of orth vectors in the common indices set
    if numOrth >= k
        setFlag = 1; %+ setFlag; %to ensure that it is set all 6 times
        removalFlag = 0;
    end   
    
    if ~removalFlag
    i = i +1;
    end
    
end

if setFlag %>= k-1
  out = sets{i-1}; % always true, removalFlag has to be 0 for setFlag to be 1. ~removalFlag increments i.
else
    out = [];
end
% out = sets{1};
% for i = 2:iter
%     out = union(out,sets{i});
% end

