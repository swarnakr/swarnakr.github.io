function op = decoderLBC(mLOrMap,m)

mLOrMap=0;
%message bit size
iterMat = [repmat(50,1,5) repmat(1000,1,5)];
[H G] = hammgen(4); % hamming(7,4)
n=size(H,2); k=size(G,1);
Gnew = [G(:,n-k+1:end) G(:,1:n-k)];%change structure of G
m=k;

% C  = zeros(2^m,n); %All possible cws
for i = 0:2^k-1
    msg = base2dec(dec2bin(i,m).',2).';
    C(i+1,:) = mod(msg*Gnew,2);
end

R=k/n;
SNRIndB=[0:1:6]; SNR=10.^(SNRIndB/10);
N0=(1./SNR)./R;

for i=1:length(SNRIndB)
    sigma=sqrt(N0(i)/2);
%     totErrorsML = 0; totErrorsMap = 0;
    iterMax = iterMat(i);
    parfor numIter = 1:iterMax
%         numIter
        ipIdx = ceil(rand*2^k);
        ip = C(ipIdx,:);
        ipBpsk = bpsk(ip);
        rv = ipBpsk+ sigma*randn(1,length(ipBpsk));
        
%         if mLOrMap
            [opML numErrorsML{numIter}] = mLLBC(rv,C,ip);
            
%         else
            [opMAP numErrorsMap{numIter}] = mapLBC(rv,C,sigma,ip,m,k);
            
%         end
% toc;
    end
    
    numErrorsMLMat = cell2mat(numErrorsML);
    numErrorsMapMat = cell2mat(numErrorsMap);
    totErrorsML = sum(numErrorsMLMat);
    totErrorsMap = sum(numErrorsMapMat);
    
%     toc;
disp(i)
    berML(i) = totErrorsML/(n*iterMax);
    berMap(i) = totErrorsMap/(n*iterMax);
    
end


figure, semilogy(SNRIndB,berML,'b-o'), title('BER for ML'),ylabel('BER'),xlabel('Eb/No (dB)'),grid;
figure, semilogy(SNRIndB,berMap,'b-o'), title('BER for MAP'), ylabel('BER'), xlabel('Eb/No (dB)'), grid;

end

function [opDecoded numErrors]  = mLLBC(r,C,ip)

[val idx]   = min(r*(2*C.'-1),[],2);
opDecoded = C(idx,:);
numErrors = size(find([ip- opDecoded]),2);

end

function [op numErrors] = mapLBC(r,C,sig,ip,m,k)
op = zeros(1,m);
for i=1:m
    ind0 = find(C(:,i)==0)';
    ind1 = setdiff(1:2^k,ind0);
    lExt0 = getLExt(C,ind0,r,sig,1,i);
    lExt1 = getLExt(C,ind1,r,sig,0,i);
    L(i) = exp(2*r(i)/(sig^2))*(lExt0/lExt1);
end

indOne = find(L<1);
op(indOne)=1;

numErrors = size(find([ip(1:m)- op]),2);

end
function lExt = getLExt(C,ind,r,sig,bitZero,bitNo)

lExt =0;
for i=1:length(ind)
    
    [~, cExt] = find(C(ind(i),:)==0); % same for both cases
    if bitZero
        cExt = setdiff(cExt,bitNo);
    end
    if isempty(cExt)
        lExt  = lExt + 1; %corres to exp(0)
    else
        lExt  = lExt  + exp(2*sum(r(cExt))/(sig^2));
    end
end
end

function [op]=bpsk(bits)

op=ones(1,length(bits));
op(find(bits==1))=-1;
end
