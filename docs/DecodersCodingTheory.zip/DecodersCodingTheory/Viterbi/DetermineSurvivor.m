function [stageCur stageNxt] = DetermineSurvivor(stageCur,stageNxt,stateNxt,stateCur,dist)

if stateCur.in == 0
    stageCur{stateCur.st}.n{1}  = stateNxt.st; %1 is first branch, 0 is second branch
else
    stageCur{stateCur.st}.n{2}  = stateNxt.st;
end

stageCur{stateCur.st}.valid = 1;

if(isnan(stageNxt{stateNxt.st}.p{1}))
    stageNxt{stateNxt.st}.p{1}  = stateCur.st;
    stageNxt{stateNxt.st}.valid = 1;
    stageNxt{stateNxt.st}.metric  = stageCur{stateCur.st}.metric+dist;
    stageNxt{stateNxt.st}.surv  = stateCur.st;
else
    stageNxt{stateNxt.st}.p{2} = stateCur.st;
    stageNxt{stateNxt.st}.valid = 1;
    
    
    if(stageNxt{stateNxt.st}.metric<=stageCur{stateCur.st}.metric+dist)
        stageNxt{stateNxt.st}.surv  =stageNxt{stateNxt.st}.p{1};
    else
        stageNxt{stateNxt.st}.surv  = stateCur.st;
        stageNxt{stateNxt.st}.metric  = stageCur{stateCur.st}.metric+dist;
    end
end

end