function stage = InitializeStage(numStates)

for i = 1:numStates
    stage{1}{i}.p{1}   = NaN;
    stage{1}{i}.p{2}   = NaN;
    stage{1}{i}.n{1}   = NaN;
    stage{1}{i}.n{2}   = NaN;
    stage{1}{i}.metric   = -100000;
    stage{1}{i}.valid  = 0;
    stage{1}{i}.surv   = NaN;
end

end