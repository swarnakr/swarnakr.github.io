function op = getSurvivorPath(stage,k)

lenStag = length(stage);
survPath = zeros(1,lenStag+1);
metric = zeros(1,lenStag+1);

branch = ones(1,lenStag);
branch(end) = 0; survPath(end) = 1;

metric(end)  = stage{lenStag}{1}.metric;
metric(end-1) = stage{lenStag}{1}.metric; %Initialize
survPath(end-1) = stage{lenStag}{1}.surv;

for i=lenStag-1:-1:1 %looking back
    survPath(i) = stage{i}{survPath(i+1)}.surv;
    metric(i) = stage{i}{survPath(i+1)}.metric;

    if(stage{i}{survPath(i+1)}.n{1} == survPath(i+2))
        branch(i) = 0;
    end
end

op = branch(1:k);
    