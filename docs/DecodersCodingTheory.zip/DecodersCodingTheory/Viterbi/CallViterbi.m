function CallViterbi()

m = 100; %totErrors = 0;
iterMat = [repmat(100,1,4) repmat(1000,1,5)];

g{1} = [1 0 1 1 0 0];
g{2} = [1 1 0 1 0 0];
g{3} = [1 1 1 1 0 0];
n = length(g); R = 1/3;
mem = 3;
msg = round(rand(1,m));

SNRIndB=[0:1:6]; SNR=10.^(SNRIndB/10);
N0=(1./SNR)./R;

parfor i=1:length(SNRIndB)
    sigma=sqrt(N0(i)/2);
    iterMax = iterMat(i);
    [ber{i} fer{i}] = BERCalc(msg,g,n,mem,m,iterMax,sigma);
    %     numErrorsMat = cell2mat(numErrors);
end

berMat = cell2mat(ber);
ferMat = cell2mat(fer);

figure, semilogy(SNRIndB,berMat,'b-o'), title('BER for Viterbi'),ylabel('BER'),xlabel('Eb/No (dB)'),grid;
figure, semilogy(SNRIndB,ferMat,'b-o'), title('FER for Viterbi'),ylabel('FER'),xlabel('Eb/No (dB)'),grid;
end


function code = ConvEncode(msg,g,n)
for i = 1:n
    y{i} = mod(conv(msg,g{i}),2);
end
code = zeros(1,n*length(y{1}));

for i = 0:n-1
    code(1+i:n:end) = y{i+1};
end
end

function [op]=bpsk(bits)

op=ones(1,length(bits));
op(find(bits==0))=-1;
end

function [ber fer] = BERCalc(msg,g,n,mem,m,iterMax,sigma)
totErrors=0; blockErr=0;
for numIter = 1:iterMax
    c = ConvEncode(msg,g,n);
    CBpsk = bpsk(c);
    trellis = poly2trellis(4,[11 13 16]);
    code = convenc(msg,trellis); %doesn't w
    rv = CBpsk+ sigma*randn(1,length(CBpsk));
    [op numErrors] = DecodeViterbi(rv,n,mem,m,msg);
    totErrors = totErrors + numErrors;
    if numErrors~=0
        blockErr = blockErr + 1;
    end
end
    ber = totErrors/(length(rv)*iterMax);
    fer = blockErr/iterMax;

end