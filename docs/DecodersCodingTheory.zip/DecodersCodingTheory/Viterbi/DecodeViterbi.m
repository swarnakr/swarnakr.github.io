function [decMsg,numErrors] = DecodeViterbi(r,n,mem,k,msg)

numStages = k+mem;
numStates = 2^mem;
opPart= 1;

for i = 1:mem
    stateCur.m{i} = 0;
end %Initialize

stateCur.st    = 1;
stateCur.in    = 0;

stage = InitializeStage(numStates);
stage{1}{1}.valid = 1;
stage{1}{1}.surv  = 1;
stage{1}{1}.metric  = 0;

for i = 1:numStages
    
    if(i~=1)
        opPart = opPart+n;
    end
    stage0 = InitializeStage(numStates);
    stage = [stage stage0];
    
    for l = 1:numStates
        if(stage{i}{l}.valid)
            stateCur.st = l;
            val = l-1;
            stateCur = getState(val,stateCur,mem);
              
            stateCur.in   = 0;
            [o,stateNxt] = getStateDiag(stateCur,n,mem);
            branchMet    = getBranchMetric(o,r,opPart,n);
            [stage{i} stage{i+1}] = DetermineSurvivor(stage{i},stage{i+1},stateNxt,stateCur,branchMet);
            
            if(i<=k) %ip 1 for first k stages only, then zero termination
                stateCur.in   = 1;
                [o,stateNxt] = getStateDiag(stateCur,n,mem);
                branchMet    = getBranchMetric(o,r,opPart,n);
                [stage{i} stage{i+1}] = DetermineSurvivor(stage{i},stage{i+1},stateNxt,stateCur,branchMet);
                
            end
        end
    end
end

decMsg = getSurvivorPath(stage,k);
numErrors = sum(decMsg~= msg);
end


function branchMet = getBranchMetric(op,r,opPart,n)

rhat = r(opPart:opPart+n-1);   
branchMet = sum((op-rhat).^2);
end


function stateCur = getState(val,stateCur,mem)

for i = mem-1:-1:0
    if((val - 2^i)>=0)
        stateCur.m{i+1} = 1;
        val = val-2^i;
    else
        stateCur.m{i+1} = 0;
    end
end
end