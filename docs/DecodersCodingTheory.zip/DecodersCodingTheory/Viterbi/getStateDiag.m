function [op,stateNxt] = getStateDiag(stateCur,n,m)

y{1} = mod(stateCur.in + stateCur.m{2} + stateCur.m{3},2); %must be changed according to generator polynomial
y{2} = mod(stateCur.in + stateCur.m{1} + stateCur.m{3},2);
y{3} = mod(stateCur.in + stateCur.m{1} + stateCur.m{2} + stateCur.m{3},2);

op = zeros(1,n*length(y{1}));
for i = 0:n-1
    op(1+i:n:end) = y{i+1};
end

op(op==0) = -1;
stateNxt.st = 0;

for i = 0:m-1
    if(i+1==1)
        stateNxt.m{i+1} = stateCur.in;
    else
        stateNxt.m{i+1} = stateCur.m{i};
    end
    stateNxt.st = stateNxt.st+ (2^i)*stateNxt.m{i+1};
end
stateNxt.st = stateNxt.st+1;
end