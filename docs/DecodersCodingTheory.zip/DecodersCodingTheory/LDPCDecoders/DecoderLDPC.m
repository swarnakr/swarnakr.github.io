function op=DecoderLDPC(h,rows,cols,ind,r,c,llr,iterMax,channel)

op(1,1:cols)=0;

msgPass=struct('c2bPrev',sparse(rows,cols,0),'c2b',sparse(rows,cols,0),'b2c',sparse(rows,cols,0));
msgPass.b2c(ind)=llr(c);

nodeBitMsg=sparse(rows,cols,0);
nodeCheckMsg=sparse(rows,cols,0);

for iter=1:iterMax
    
    nodeBitMsg(ind)=tanh( ( (msgPass.b2c(ind))- msgPass.c2bPrev(ind))  /2);
    
    for i=1:rows
        cc=c(find(r==i));
        rowtemp=nodeBitMsg(i,:);    %ith row of nodeBitMsg
        
        rowtemp0=zeros(1,length(cc));
        rowtemp0=rowtemp(cc);
        ze=find(rowtemp0==0);
        
        if isempty(ze)==1
            rowtemp_int1=zeros(1,length(cc));
            rowtemp_int1(1:length(cc))=prod(rowtemp0);
            nodeCheckMsg(i,cc)=rowtemp_int1./rowtemp0;
        end
    end
        
    msgPass.c2b(ind)=2*atanh(nodeCheckMsg(ind));   %check to bit messages
    
    msgPass.c2b(find(msgPass.c2b==inf))=100;
    msgPass.c2b(find(msgPass.c2b==-inf))=-100;
    
    msgPass.c2bPrev(ind)=msgPass.c2b(ind);
    sum_of_b=sum(msgPass.c2b,1);
    tempsum=sum_of_b+llr;
    msgPass.b2c(ind)=tempsum(c);
    
    switch channel
        case 'awgn'
            op(find(tempsum>=0))=0;
            op(find(tempsum<0))=1;
        case 'bsc'
            op(find(tempsum>=1))=0;
            op(find(tempsum<1))=1;
    end
    
    if mod(op*h',2)==0
        break
    end
    
end

