function op=DecodeBec(rows,cols,ind,r,c,llr,iterMax)

op(1,1:cols)=0;

msgPass=struct('c2bPrev',sparse(rows,cols,0),'c2b',sparse(rows,cols,0),'b2c',sparse(rows,cols,0));

op = llr;
msgPass.b2c(ind)=llr(c);
nodeBitMsg=sparse(rows,cols,0);
nodeCheckMsg=sparse(rows,cols,0);

for iteration=1:iterMax
    
    nodeBitMsg(ind)=msgPass.b2c(ind);
    
    for i=1:rows
        cc=c(find(r==i));
        rowtemp=nodeBitMsg(i,:);        
        rowtemp0=zeros(1,length(cc));
        rowtemp0=rowtemp(cc);
        temp=find(rowtemp0==2);    %2 corres erasure
        
        if length(temp)>=2
            nodeCheckMsg(i,cc)=2;
            
        elseif isempty(temp)==1
            rowtemp01=zeros(1,length(cc));
            rowtemp01(1:length(cc))=mod(sum(rowtemp0),2);
            nodeCheckMsg(i,cc)=rowtemp01 - rowtemp0;
            
        else
            %             rowtemp01=zeros(1,length(cc));
            remVar = setdiff(1:length(cc),temp);
            remVar = cc(remVar);
            nodeCheckMsg(i,cc(temp)) =mod(sum(rowtemp(remVar)),2);            
        end        
    end
    
    msgPass.c2b(ind)=(nodeCheckMsg(ind));   %check to bit messages
    
    for j=1:cols
        rr=r(find(c==j));
        coltemp=msgPass.c2b(:,j);
        [rNonEras cNonEras] = find(coltemp(rr)~=2);
        if ~isempty(rNonEras)
            msgPass.b2c(rr,j) = coltemp(rNonEras(1),cNonEras(1));            
            op(j)=0;
        end
    end
    
    if isempty(find(op==2))
        break
    end    
end

