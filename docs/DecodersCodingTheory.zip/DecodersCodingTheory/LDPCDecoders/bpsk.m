function [op]=bpsk(bits)

op=ones(1,length(bits));
op(find(bits==1))=-1;
end