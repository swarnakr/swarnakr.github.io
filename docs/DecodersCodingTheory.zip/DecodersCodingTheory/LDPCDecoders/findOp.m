function [numErrors blockerrors] = findOp(h,rows,cols,ind,r,c,N0,p,ep,i)
iterMax=10;
ip=zeros(1,cols);
ipBpsk=bpsk(ip);
cwLen = length(ip);
channel = 'bec';

switch channel
    case 'awgn'
        sigma=sqrt(N0(i)/2);
        rv=ipBpsk+ sigma*randn(1,length(ipBpsk));
        llr=(4/N0(i))*rv;
        op=DecoderLDPC(h,rows,cols,ind,r,c,llr,iterMax,channel);
        
    case 'bsc'
        rv = ip +  bsc(zeros(1,cwLen),p(i));%randerr(1,cwLen,[0 1;1-p(i) p(i)]);
        numOnesRv= sum(rv);
        %                 rvBpsk=bpsk(rv);
        llr=((-1*ones(1,cwLen)).^rv)*log((1-p(i))/p(i));
        op=DecoderLDPC(h,rows,cols,ind,r,c,llr,iterMax,channel);
        numOnesOp= sum(op);
        
        %             switch sign(numOnesRv - numOnesOp) %can use exact number to see how much better (actuall need to subtract also)
        %                 case 0
        %                     disp('No change');
        %                 case +1
        %                     disp('Improvement');
        %                 case -1
        %                     disp('Worse');
        %             end
        
    case 'bec'
        rv = ip + 2.*bsc(zeros(1,cwLen),ep(i));
%         rv(2)=2;
        op=DecodeBec(rows,cols,ind,r,c,rv,iterMax);
end
%
%         if size(find(op),2)
%             disp('Decoding failure');
%         else
%             disp('Decoding Suceess');
%
%         end

%         errors=zeros(1,length(op));
%         errors(find(ip~=op))=1;
%
numErrors = size(find([ip- op]),2);

if numErrors~=0
    blockerrors=1;
else
    blockerrors=0;
end

end

function [op]=bpsk(bits)

op=ones(1,length(bits));
op(find(bits==0))=-1;
end