function RunDecoderLDPC()
clear all;
% Irregular:
%
% H=[ 1  1  0  1  1  0  0  1  1  1;
%     1  0  1  1  1  0  1  1  1  0;
%     0  1  1  1  0  1  1  1  0  1;
%     0  1  0  0  1  1  1  0  0  1;
%     1  0  1  0  0  1  0  0  1  0];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load 128x256regular.mat H
load ha.mat Ha
H=full(Ha);

% H=[ 1  1  1  1  0  1  1  0  0  0;
%     0  0  1  1  1  1  1  1  0  0;
%     0  1  0  1  0  1  0  1  1  1;
%     1  0  1  0  1  0  0  1  1  1;
%     1  1  0  0  1  0  1  0  1  1];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

totalBlocksT=[50 50 100 300 500 700 800 900 900 1500 1500 1500 1500];
maxBlErr=30;

ind=find(H==1);
[r,c]=ind2sub(size(H),ind);
[rows,cols]=size(H);
n=cols;k=n-rows;

R=k/n;
SNRIndB=[0 2.5:.7:5.5]; SNR=10.^(SNRIndB/10); %SNRIndB=[0 2.5:.3:5.5];

p = [0.14:-0.02:0.06];
ep = .65:-0.05:0.45;

[max_check_degree,~,~,max_variable_degree,~,~]=one_finder(H); %in case it's irregular
Rother = 1- (max_variable_degree/max_check_degree);

N0=(1./SNR)./Rother;

h=sparse(H);

for i=1:length(SNR)
    
    totalBlocks =totalBlocksT(i);
    numErrors={}; blockerrors={};
    parfor block=1:totalBlocks 
%         tic;
        [numErrors{block} blockerrors{block}]= findOp(h,rows,cols,ind,r,c,N0,p,ep,i);
%         t=toc;
        
        %         block
        %         block=block+1;
        
    end
    numEMat = cell2mat(numErrors);
    blockEMat = cell2mat(blockerrors);
    
    blErrInd = find(blockEMat,maxBlErr);
    blockMax = blErrInd(end);
    if length(blErrInd) <maxBlErr
        blockMax = length(blockEMat);
    end
    biterrors=sum(numEMat(1:blockMax));
    BER(i)=biterrors/(blockMax*n);
    FER(i)=sum(blockEMat(1:blockMax))/blockMax;
    fprintf(1,'\n\n SNR: %d \n',SNRIndB(i))
    
end

t=toc;
disp(t);
save('BER.mat','BER');
save('FER.mat','FER');
save('N0.mat','N0');

figure(1), semilogy(fliplr(ep),fliplr(ber200),'b-o'),title('BER for BSC'),ylabel('BER'),xlabel('transition probability'),grid; hold on; %sigma1200,ber1200,'g-o',sigma4000,ber4000,'r-o'
semilogy(fliplr(ep),fliplr(ber1200),'g-o'),
semilogy(fliplr(ep),fliplr(ber4000),'r-o'),
figure(1);legend('n=200','n=1200','n=4000');

figure(2), semilogy(fliplr(ep),fliplr(fer200),'b-o'),title('FER for BSC'),ylabel('FER'),xlabel('transition probability'),grid; hold on;
semilogy(fliplr(ep),fliplr(fer1200),'g-o'),
semilogy(fliplr(ep),fliplr(fer4000),'r-o'),
figure(2);legend('n=200','n=1200','n=4000');

% sigma200=fliplr(sqrt(N0200/2)); sigma1200=fliplr(sqrt(N01200/2)); sigma4000=fliplr(sqrt(N04000/2));
% figure(1), semilogy(fliplr(p200),fliplr(ber200),'b-o'),title('BER for BSC'),ylabel('BER'),xlabel('transition probability'),grid; hold on; %sigma1200,ber1200,'g-o',sigma4000,ber4000,'r-o'
% semilogy(fliplr(p1200),fliplr(ber1200),'g-o'),
% semilogy(fliplr(p4000),fliplr(ber4000),'r-o'),
% figure(1);legend('n=200','n=1200','n=4000');
% 
% figure(2), semilogy(fliplr(p200),fliplr(fer200),'b-o'),title('FER for BSC'),ylabel('FER'),xlabel('transition probability'),grid; hold on;
% semilogy(fliplr(p1200),fliplr(fer1200),'g-o'),
% semilogy(fliplr(p4000),fliplr(fer4000),'r-o'),
% figure(2);legend('n=200','n=1200','n=4000');

save('valuesForGraph')
end
%Needed?
% rand('seed',584);
% randn('seed',843);

function [op]=bpsk(bits)

op=ones(1,length(bits));
op(find(bits==0))=-1;
end