function runLdpcAndDE(n)
close all; n=1000;

%% Regular LDPC Eg 
%% Generate Matrix
lambdaReg = [0 0 1]; % (3,4) regular
rhoReg = [0 0 0 1];
[H rate] = GenLdpc(lambdaReg, rhoReg , n);
checkGirth(H);

figure; subplot(3,1,1); spy(H); 
title('Sparsity of Matrix');
subplot(3,1,2); hist(sum(H,1)); axis([ 0 length(lambdaReg) 0 n]); 
title('Check Node Distribution');xlabel('degree');ylabel('number of nodes');
subplot(3,1,3); hist(sum(H,2)); axis([ 0 length(rhoReg) 0 n]); 
title('Bit Node Distribution');xlabel('degree');ylabel('number of nodes');

%% Density Evolution
eThresh=0.6474;  iterMax=100;
xL  = DensEvolBEC(fliplr(lambdaReg), fliplr(rhoReg), eThresh, iterMax);
xL  = DensEvolBEC2(fliplr(lambdaReg), fliplr(rhoReg), eThresh);
% axis([ 0 1000 0 0.42944 ])

%% Irregular LDPC Eg 
%% Generate Matrix
lambdaIrreg  = [0 0.409 0.202 0.0768 0 0 0.1971 0.1151]; %case irregular
rhoIrreg  = [0 0 0 0 0.5 0.5];
[H rate] = GenLdpc(lambdaIrreg, rhoIrreg, n);
checkGirth(H);

figure; subplot(3,1,1); spy(H) ;
title('Sparsity of Matrix');
subplot(3,1,2); hist(sum(H,1)), axis([ 0 length(lambdaIrreg) 0 n]); %axis([ 0 size(H,2) 0 size(H,1)])
title('Check Node Distribution');xlabel('degree');ylabel('number of nodes');
subplot(3,1,3); hist(sum(H,2)), axis([ 0 length(rhoIrreg) 0 n]); 
title('Bit Node Distribution');xlabel('degree');ylabel('number of nodes');

%% Density Evolution
e=0.5;  iterMax=1000;
xL  = DensEvolBEC(fliplr(lambdaIrreg), fliplr(rhoIrreg), eThresh, iterMax);
xL  = DensEvolBEC2(fliplr(lambdaIrreg), fliplr(rhoIrreg), eThresh);
plot(1:lastIter+50, xL(1:lastIter+50))

title('Density Evolution for Irregular LDPC in BEC');xlabel('Iter');ylabel('Average erasure probability');
% axis([ 0 1000 0 e])
%end

function checkGirth(H)

O=H*H';  
minusDiagO =  - diag(O);
O = O + diag(minusDiagO);
girth=max(O);
girth4=max(girth);

if girth4<2 
  disp('No girth 4 cycle')
else
   disp('Has girth 4 cycle')  
end    

% end