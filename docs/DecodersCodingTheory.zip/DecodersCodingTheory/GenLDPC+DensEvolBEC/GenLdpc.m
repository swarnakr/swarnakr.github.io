function [H rate] = GenLdpc(L, R, n)

rate = 1-dot(L,1:length(L))/dot(R,1:length(R));
nr = round((1-rate)*n);

%% Correct differences arising due to lamda and rho entries not diving n
lambda = ceil(n*L);
i=1;
while sum(lambda)~=n %actual number made to sum to n
    if lambda(i)
        lambda(i)=lambda(i)-1;
    end
    i=i+1;
end

rho = round(nr*R);
remEdges= dot(lambda,1:length(lambda))-dot(rho,1:length(rho));
if remEdges~=0
    k = find( rho>0 ,1 ,'last');
    rho(k) = rho(k)-abs(remEdges);  % remove the remaining edges
    % add corresponding number of check nodes of higher or lower degree
    rho = [rho 0]; % this is just an initialization step
    rho(k+sign(remEdges)) = rho(k+sign(remEdges))+abs(remEdges);
end
edges = dot(lambda,1:length(lambda)); % number of edges

%% Generate LDPC H
nodeV = getNodeInit(lambda);
nodeC = getNodeInit(rho);

sigma = randperm(edges);
nodeV = nodeV(sigma);
H = sparse(nodeC, nodeV, 1);

%% Remove multi edges

while max(max(H))>1
    [c v] = find(H>1, 1);
    [cAll vAll] = find(H==1);
    randEdge = round(rand*length(vAll));
    while H(c,vAll(randEdge))>0 || H(cAll(randEdge),v)>0
        randEdge = round(rand*length(vAll));
    end
    H(c,v) = H(c,v) - 1;
    H(cAll(randEdge),vAll(randEdge)) = 0;
    H(cAll(randEdge),v) = 1;
    H(c,vAll(randEdge)) = 1;
end

%% Remove girth 4 cycles
O=H*H';
minusDiagO =  - diag(O);
O = O + diag(minusDiagO);

while max(max(O))>1
    [cAll vAll] = find(H==1); %all edges
    [r1 r2] = find(O>1,1);
    cols1 = find(H(r1,:)==1);
    cols2 = find(H(r2,:)==1);
    girth4Cols = intersect(cols1,cols2);
    
    randNo = ceil(rand*length(vAll));
    try
    while H(r1,vAll(randNo))==1 || H(cAll(randNo),girth4Cols(1))==1
        randNo = ceil(rand*length(vAll));
    end
    catch
        disp()
    end
    H(r1,girth4Cols(1))=0; %set one of them to 0. can be any
    H(cAll(randNo),vAll(randNo))=0;
    H(r1,vAll(randNo)) =1;
    H(cAll(randNo),girth4Cols(1)) =1;
    
    O=H*H'; %update O
    minusDiagO =  - diag(O);
    O = O + diag(minusDiagO);
    
end
end


function node = getNodeInit(lambdaOrRho)

node=[]; num=1;
for i=1:length(lambdaOrRho)
    if lambdaOrRho(i)
        node = [node repmat(num:num+lambdaOrRho(i)-1,1,i)];
        num=num+lambdaOrRho(i);
    end
end
end