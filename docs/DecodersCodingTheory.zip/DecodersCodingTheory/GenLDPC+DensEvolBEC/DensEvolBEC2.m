function xL  = DensEvolBEC2(lambda, rho,eThresh)

colors=['g';'b';'k';'r';'y';'m';'c']; c=1; 
xL0 = 0:0.01:1;
figure;
plot(xL0,zeros(1,length(xL0)),'-k'); hold on;
yAxis = .1:-0.01:-0.6;
plot(repmat(eThresh,1,length(yAxis)),yAxis,'-k');

f=[];
eT=[eThresh-0.2:0.07:eThresh eThresh:0.07:eThresh+0.2]
for c=1:length(eT)
    e=eT(c);
    f=[];
    for xL = 0:0.01:1
        fxL = e*polyval(lambda, 1-polyval(rho, 1-xL));
        f = [f (fxL - xL)];
%                 f = [f (e*(1-(1-xL)^3)^2 - xL)];
    end
    
    string=sprintf('e=%0.2f',e);
    plot([0:0.01:1], f,colors(c)), hold on;
%     text(0.2+(c*0.077),-0.15+(c*0.03),string);
 text(0.2+(c*0.077),-0.07+(c*0.03),string);
    
end

text(eThresh+0.01,-0.4,'Threshold');
title('Density Evolution for Irregular LDPC in BEC');xlabel('Average erasure probability');ylabel('f(x) - x');
