function xL  = DensEvolBEC(lambda, rho,eThresh,iterMax)

% Threshold (3, 6); 0.039
%(4,8)= 0.047, 0.42943
%(4, 10) = 0.0368
%e = 0.42943;
% colors=['g';'b';'k';'r';'y';'m';'f']; c=1; figure;
% for e=eThresh-0.3:0.1:eThresh+0.3
xL(1) = eThresh;%f(1)=0;
for i = 1:iterMax
    xL(i+1) = eThresh*polyval(lambda, 1-polyval(rho, 1-xL(i)));
    if( xL(i+1) >= xL(i) )
        xLStar = xL(i);
        %         return;
    end
end

% end

ind = find(xL);
figure;
plot(xL(1:ind(end)),'-k'), hold on;
title('Density Evolution for Regular LDPC in BEC');xlabel('Iter');ylabel('Average erasure probability');

c=[]; v=[]; vInv=[];
for x=0:0.1:1
    c = [c 1-polyval(rho,x)];
    v = [v eThresh*polyval(lambda,x)];
    %         vInv = [vInv (1/e)*finverse(polyval(lambda,x))];
    
end

c = fliplr(c);
figure
plot(0:0.1:1,c,'-g'), hold on,
% plot(0:0.1:1,v,'-b');
plot(v,0:0.1:1,'-r');
title('c(x) Vs v(x)');xlabel('erasure probability');ylabel('c(x) and v(x)');
legend('c(x)','v(x)');