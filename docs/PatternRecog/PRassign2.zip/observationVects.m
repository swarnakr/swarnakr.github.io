clc;clear all;

A=load('clusters_new.txt');
path1='E:\CS669\fromPRassign2\Group01\class1\';
extn='.txt';

path1='E:\CS669\fromPRassign2\Group01\class1\';
pathnew='E:\CS669\fromPRassign2\DataVectors_new\1\';
k=0;
for i=1:160
    clear A1
    path=sprintf('%s%d%s', path1, i, extn);
    A1=load(path);
    n1=size(A1,1);
    clear B1;    
    for j=1:n1
        k=k+1;
        B1(j)=A(k);
    end    
    path=sprintf('%s%d%s', pathnew, i, extn);
    dlmwrite(path,B1);
end

path1='E:\CS669\fromPRassign2\Group01\class2\';
pathnew='E:\CS669\fromPRassign2\DataVectors_new\2\';
for i=1:160
    clear A1
    path=sprintf('%s%d%s', path1, i, extn);
    A1=load(path);
    n1=size(A1,1);
    clear B1;    
    for j=1:n1
        k=k+1;
        B1(j)=A(k);
    end    
    path=sprintf('%s%d%s', pathnew, i, extn);
    dlmwrite(path,B1);
end

path1='E:\CS669\fromPRassign2\Group01\class3\';
pathnew='E:\CS669\fromPRassign2\DataVectors_new\3\';
for i=1:160
    clear A1
    path=sprintf('%s%d%s', path1, i, extn);
    A1=load(path);
    n1=size(A1,1);
    clear B1;    
    for j=1:n1
        k=k+1;
        B1(j)=A(k);
    end    
    path=sprintf('%s%d%s', pathnew, i, extn);
    dlmwrite(path,B1);
end
