% % PCA
% clc; clear all; 
% 
% A1=load('Full_Data.txt');
% [rows,cols]=size(A1);
% M=mean(A1);
% c=zeros(1,39);
% A=zeros(rows,cols);
% 
% for i=1:rows
%     c=A1(i,:)-M;
%     A(i,:)=c(:);
% end
% 
% lambda=zeros(cols,1);
% C=cov(A);
% [eigenvect,eigenval]=eig(C);
% for i=1:cols
%     for j=1:cols
%         if(i==j)
%         lambda(i)=eigenval(i,j);
%         end
%     end
% end
% Q=eigenvect(1:39,27:39);
% 
path1='E:\CS669\PRassign2\Group01\class3\';
path2='E:\CS669\PRassign2\PCAData\class3\';
extn='.txt';
for i=1:160
    clear Z;
    path=sprintf('%s%d%s', path1, i, extn);
    Z=load(path);
    r=size(Z,1);
    clear F;
    for j=1:r
        G=Z(j,:)-M;
        Y(j,:)=G(:);
    end
    F=(Q'*Y')';
    pathZ=sprintf('%s%d%s', path2, i, extn);
    dlmwrite(pathZ,F,'delimiter',' ');
end
    
    

        
        