clc; clear all; close all;

L=120; % training data
k=5; % no. of states in class
extn='.txt';
path1='E:\CS669\fromPRassign2\DataVectors_new\3\';
M=8; % no. of symbols
c=zeros(k,M);

for n=1:L
    path=sprintf('%s%d%s', path1, n, extn);
    O=load(path); 
    T=size(O,2);
    Num=floor(T/k);
    b=zeros(k,Num);
    b=reshape(O(1:k*Num),Num,k);   
    b=b';
   for m=1:k
       for i=1:Num
           if(b(m,i)==1) c(m,1)=c(m,1)+1; end
           if(b(m,i)==2) c(m,2)=c(m,2)+1; end
           if(b(m,i)==3) c(m,3)=c(m,3)+1; end
           if(b(m,i)==4) c(m,4)=c(m,4)+1; end
           if(b(m,i)==5) c(m,5)=c(m,5)+1; end
           if(b(m,i)==6) c(m,6)=c(m,6)+1; end
           if(b(m,i)==7) c(m,7)=c(m,7)+1; end
           if(b(m,i)==8) c(m,8)=c(m,8)+1; end
           if(b(m,i)==9) c(m,9)=c(m,9)+1; end
       end
   end
   clear b;        
end

for i=1:k
    for j=1:M
        c1(i,j)=c(i,j)/sum(c(i,:));
    end
end
c1 % B matrix