sig = wavread('a.wav');
semilogy(sig); h=gcf; saveas(h,'signal.png');
qsz=[2 3 5];
for i=1:3
    Lev=2^qsz(i);
    delta = (max(sig)-min(sig))/Lev;
    qsig=quant(sig,delta);
    semilogy(qsig);
    h=gcf;  saveas(h,sprintf('quantizedsignal%d.png',i));

    error=sig-qsig;
    hist(error,10);
    h=gcf; saveas(h,sprintf('hist%d.png',i));
    semilogy(error);
    h=gcf; saveas(h,sprintf('error%d.png',i));
end
  